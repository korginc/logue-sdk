#pragma once
/*
    BSD 3-Clause License

    Copyright (c) 2023, KORG INC.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

//*/

/*
 *  File: delay.h
 *
 *  Dummy delay effect template instance.
 *
 */

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <climits>

#include "unit_delfx.h" // Note: Include base definitions for delfx units

#include "utils/buffer_ops.h" // for buf_clr_f32()
#include "utils/int_math.h"   // for clipminmaxi32()

class Delay
{
public:
  /*===========================================================================*/
  /* Public Data Structures/Types/Enums. */
  /*===========================================================================*/

  enum
  {
    BUFFER_LENGTH = 0x40000U,
  };

  enum
  {
    PROBABILITY = 0,
    LENGTH,
    MIX,
    LENGTH_RAND,
    CHAIN,
    DEPTH,
    INVERT,
    NUM_PARAMS,
  };

  // Note: Make sure that default param values correspond to declarations in header.c
  struct Params
  {
    int16_t probability{25};
    int16_t length{30};
    int16_t mix{100};
    int16_t length_rand{60};
    int16_t chain{120};
    int16_t depth{100};
    int16_t invert{0};

    void reset()
    {
      probability = 25;
      length = 30;
      mix = 100;
      length_rand = 60;
      chain = 120;
      depth = 100;
      invert = 0;
    }
  };

  struct States
  {
    bool active{false};
    float active_length_now{0};
    float active_length{5};
    float gate_coef_now{1.f};
    int32_t chain_length{100};
    int32_t chain_counter{0};

    void
    reset()
    {
      active = false;
      active_length_now = 0;
      active_length = 30;
      gate_coef_now = 1.f;
      chain_length = 100;
      chain_counter = 0;
    }
  };

  /*===========================================================================*/
  /* Lifecycle Methods. */
  /*===========================================================================*/

  Delay(void)
  {
  }
  ~Delay(void) {} // Note: will never actually be called for statically allocated instances

  inline int8_t Init(const unit_runtime_desc_t *desc)
  {
    if (!desc)
      return k_unit_err_undef;

    // Note: make sure the unit is being loaded to the correct platform/module target
    if (desc->target != unit_header.target)
      return k_unit_err_target;

    // Note: check API compatibility with the one this unit was built against
    if (!UNIT_API_IS_COMPAT(desc->api))
      return k_unit_err_api_version;

    // Check compatibility of samplerate with unit, for NTS-1 MKII should be 48000
    if (desc->samplerate != 48000)
      return k_unit_err_samplerate;

    // Check compatibility of frame geometry
    if (desc->input_channels != 2 || desc->output_channels != 2) // should be stereo input/output
      return k_unit_err_geometry;

    // If SDRAM buffers are required they must be allocated here
    if (!desc->hooks.sdram_alloc)
      return k_unit_err_memory;
    float *m = (float *)desc->hooks.sdram_alloc(BUFFER_LENGTH * sizeof(float));
    if (!m)
      return k_unit_err_memory;

    // Make sure buffer is cleared
    buf_clr_f32(m, BUFFER_LENGTH);

    allocated_buffer_ = m;

    // Cache the runtime descriptor for later use
    runtime_desc_ = *desc;

    samplerate = desc->samplerate;

    // Make sure parameters are reset to default values
    params_.reset();

    states_.reset();

    return k_unit_err_none;
  }

  inline void Teardown()
  {
    // Note: buffers allocated via sdram_alloc are automatically freed after unit teardown
    // Note: cleanup and release resources if any
    allocated_buffer_ = nullptr;
  }

  inline void Reset()
  {
    // Note: Reset effect state, excluding exposed parameter values.
  }

  inline void Resume()
  {
    // Note: Effect will resume and exit suspend state. Usually means the synth
    // was selected and the render callback will be called again

    // Note: If it is required to clear large memory buffers, consider setting a flag
    //       and trigger an asynchronous progressive clear on the audio thread (Process() handler)
  }

  inline void Suspend()
  {
    // Note: Effect will enter suspend state. Usually means another effect was
    // selected and thus the render callback will not be called
  }

  /*===========================================================================*/
  /* Other Public Methods. */
  /*===========================================================================*/

  fast_inline void Process(const float *in, float *out, size_t frames)
  {
    const float *__restrict in_p = in;
    float *__restrict out_p = out;
    const float *out_e = out_p + (frames << 1); // assuming stereo output

    // Caching current parameter values. Consider interpolating sensitive parameters.
    // const Params p = params_;
    bool active = states_.active;

    if (!states_.active)
    {
      int32_t rnd = fx_rand() % 10000;
      int32_t probability = states_.chain_counter > 0 ? params_.probability + params_.chain : params_.probability;
      if (rnd < probability)
      {
        active = true;
        states_.active_length_now = 0;
        rnd = params_.length_rand == 0 ? 0 : fx_rand() % (2 * params_.length_rand) - params_.length_rand;
        states_.active_length = clipminmaxi32(1, params_.length + rnd, 100);
      }
    }
    else
    {
      if (states_.active_length_now > states_.active_length)
      {
        active = false;
        states_.chain_counter = states_.chain_length;
      }
    }

    states_.active = active;

    // uint32_t active_time = states_.active_time;
    // const uint32_t active_length = states_.active_length;

    float gate_coef_now = states_.gate_coef_now;
    float gate_coef;
    const float depth = params_.depth / 100.f;
    const bool invert = params_.invert == 0 ? false : true;

    for (; out_p != out_e; in_p += 2, out_p += 2)
    {
      // Process samples here

      // Note: this is a dummy unit only to demonstrate APIs, only passing through audio
      if (invert)
      {
        gate_coef = active ? (1.f - depth) : 1.f;
      }
      else
      {
        gate_coef = active ? 1.f : (1.f - depth);
      }

      gate_coef_now = gate_coef_now + (gate_coef - gate_coef_now) / 1.f;

      out_p[0] = in_p[0] * gate_coef_now; // left sample
      out_p[1] = in_p[1] * gate_coef_now; // right sample
    }
    states_.active_length_now = active ? states_.active_length_now + 1 : 0;
    states_.gate_coef_now = gate_coef_now;
    states_.chain_counter = states_.chain_counter > 0 ? states_.chain_counter - 1 : 0;
  }

  inline void setParameter(uint8_t index, int32_t value)
  {
    switch (index)
    {
    case PROBABILITY:
      value = clipminmaxi32(0, value, 300);
      params_.probability = value;
      break;

    case LENGTH:
      value = clipminmaxi32(1, value, 100);
      params_.length = value;
      break;

    case MIX:
      // Single digit base-10 fractional value, bipolar dry/wet
      value = clipminmaxi32(-1000, value, 1000);
      params_.mix = value / 1000.f; // -100.0 .. 100.0 -> -1.0 .. 1.0
      break;

    case LENGTH_RAND:
      value = clipminmaxi32(0, value, 100);
      params_.length_rand = value;
      break;

    case CHAIN:
      value = clipminmaxi32(0, value, 300);
      params_.chain = value;
      break;

    case DEPTH:
      value = clipminmaxi32(0, value, 100);
      params_.depth = value;
      break;

    case INVERT:
      value = clipminmaxi32(0, value, 1);
      params_.invert = value;
      break;

    default:
      break;
    }
  }

  inline int32_t getParameterValue(uint8_t index) const
  {
    switch (index)
    {
    case PROBABILITY:
      return params_.probability;
      break;

    case LENGTH:
      return params_.length;
      break;

    case MIX:
      // Single digit base-10 fractional value, bipolar dry/wet
      return (int32_t)(params_.mix * 1000);
      break;

    case LENGTH_RAND:
      return params_.length_rand;
      break;

    case CHAIN:
      return params_.chain;
      break;

    case DEPTH:
      return params_.depth;
      break;

    case INVERT:
      return params_.invert;
      break;

    default:
      break;
    }

    return INT_MIN; // Note: will be handled as invalid
  }

  inline const char *getParameterStrValue(uint8_t index, int32_t value) const
  {
    // Note: String memory must be accessible even after function returned.
    //       It can be assumed that caller will have copied or used the string
    //       before the next call to getParameterStrValue

    return nullptr;
  }

  inline void setTempo(uint32_t tempo)
  {
    // const float bpmf = (tempo >> 16) + (tempo & 0xFFFF) / static_cast<float>(0x10000);
    (void)tempo;
  }

  inline void tempo4ppqnTick(uint32_t counter)
  {
    (void)counter;
  }

  /*===========================================================================*/
  /* Static Members. */
  /*===========================================================================*/

private:
  /*===========================================================================*/
  /* Private Member Variables. */
  /*===========================================================================*/

  std::atomic_uint_fast32_t flags_;

  unit_runtime_desc_t runtime_desc_;

  Params params_;

  float *allocated_buffer_;

  States states_;

  float samplerate{48000.f};

  /*===========================================================================*/
  /* Private Methods. */
  /*===========================================================================*/

  /*===========================================================================*/
  /* Constants. */
  /*===========================================================================*/
};
