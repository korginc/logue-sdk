#pragma once
/*
    BSD 3-Clause License

    Copyright (c) 2023, KORG INC.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

//*/

/*
 *  File: effect.h
 *
 *  Dummy generic effect template instance.
 *
 */

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <climits>
#include <math.h>

#include "unit_genericfx.h"   // Note: Include base definitions for genericfx units

#include "utils/buffer_ops.h" // for buf_clr_f32()
#include "utils/int_math.h"   // for clipminmaxi32()
#define VEC_MIN          1.0e-10        // min normalized positive value
#define CLIP(x, min, max) ((x) < (min) ? (min) : ((x) > (max) ? (max) : (x)))
#define TIME_SCALE 0.15f
#define GAIN_SCALE 0.1f
#define GAIN_UP  GAIN_SCALE / 512
#define GAIN_DOWN -GAIN_SCALE / 512
#define GAIN_SUSTAIN 0.f

class Effect {
 public:
  /*===========================================================================*/
  /* Public Data Structures/Types/Enums. */
  /*===========================================================================*/

  enum {
    BUFFER_LENGTH = 0x40000 
  };

  enum {
    PITCH = 0U,
    CHAOS,
    DEPTH,
    PARAM4, 
    NUM_PARAMS
  };

  // Note: Make sure that default param values correspond to declarations in header.c
  struct Params {
    float param1{0.f};
    float param2{0.f};
    float depth{0.f};
    uint32_t param4{0};

    void reset() {
      param1 = 0.f;
      param2 = 0.f;
      depth = 0.f;
      param4 = 0;
    }
  };

  enum {
    PARAM4_VALUE0 = 0,
    PARAM4_VALUE1,
    PARAM4_VALUE2,
    NUM_PARAM4_VALUES,
  };

  struct Chaos {
	// Vectors
	float alpha_x[12];
	float alpha_y[12];
	float alpha_z[12];

	// Initial value 
	float x10{0.f};
	float y10{0.f};
	float z10{0.f};

	// Current Vector Field
	int w10;
	// Next Vector Field
	int w11;
	// Boundary
	int l10;
	// Next Boundary
	int l11;
	// Prev Boundary
	int l0;

	// State Variables 
	float x11;
	float y11;
	float z11;

	float x_tmp;
	float y_tmp;
	float z_tmp;
	float y_1tmp;

	float tar_x;
	float tar_y;
	float tar_z;

	// Parameters
	float a;
	float b;

	// Time to Boundary
	float tau;
	float tau_1;
	float tau_1_tmp;
	float tau_n[4];

	float tau_d;
	float amp = 0.0;
	float gain_update = 0.0;

	// State
	int state;


	enum {
		STATE_INIT = 0,
		STATE_IN_VECTOR,
		STATE_ON_BOUNDARY,
	};

	void reset_vector(float val) {
		a = 1.5;
		// b = 0.1 + (0.5 - 0.1) * val;
		b = 0.38;
		alpha_x[0] = -1.0;	alpha_z[0] = 1.0;		alpha_y[0] = 1.0+b;
		alpha_x[1] = -1.0; 	alpha_z[1] = -1.0;		alpha_y[1] = -1.0+b;
		alpha_x[2] = -1.0; 	alpha_z[2] = 1.0;		alpha_y[2] = 1.0-b;
		alpha_x[3] = -1.0; 	alpha_z[3] = -1.0;		alpha_y[3] = -1.0-b;
		alpha_x[4] =  1.0; 	alpha_z[4] = 1.0;		alpha_y[4] = 1.0-b;
		alpha_x[5] =  1.0; 	alpha_z[5] = -1.0;		alpha_y[5] = -1.0-b;
		alpha_x[6] = -1.0;	alpha_z[6] = 1.0;		alpha_y[6] = 1.0+b-a;
		alpha_x[7] = -1.0; 	alpha_z[7] = -1.0;		alpha_y[7] = -1.0+b-a;
		alpha_x[8] = -1.0; 	alpha_z[8] = 1.0;		alpha_y[8] = 1.0-b+a;
		alpha_x[9] = -1.0; 	alpha_z[9] = -1.0;		alpha_y[9] = -1.0-b+a;
		alpha_x[10] = 1.0;	alpha_z[10] = 1.0;		alpha_y[10] = 1.0-b+a;
		alpha_x[11] = 1.0; 	alpha_z[11] = -1.0;		alpha_y[11] = -1.0-b+a;


		x10 = 0.5;
		y10 = 0.2;
		z10 = -0.4;

		state = STATE_INIT;

		tau_d = 0.0;
	}

	float c_fabs(float x)
	{
		if(x < VEC_MIN) {
			return -x;
		}
		return x;
	}
	
	void first_point(float x, float y, float z) {
		if(x<=0&&y<0&&y<1&&z<0) w10=0;
			else if(x>0&&y<=0&&y<1&&z<0)	w10=1;
			else if(x<0&&y>=0&&y<1&&z<0)	w10=2;
			else if(x>=0&&y>0&&y<=1&&z<0)	w10=3;
			else if(x<0&&y>=0&&y>=1&&z<0)	w10=4;
			else if(x>=0&&y>=0&&y>1&&z<0)	w10=5;
			else if(x<0&&y<0&&y<1&&z>=0)	w10=6;
			else if(x>=0&&y<0&&y<1&&z>=0)	w10=7;
			else if(x<0&&y>=0&&y<1&&z>=0)	w10=8;
			else if(x>=0&&y>=0&&y<1&&z>=0)	w10=9;
			else if(x<0&&y>=0&&y>=1&&z>=0)	w10=10;
			else if(x>=0&&y>=0&&y>=1&&z>=0) w10=11;
	}

	float sort(float *tau_n) {
		int i,j,k;
		float tmin;
		int min=0;

		for(i=0;i<4;i++){
			if(tau_n[i] >= VEC_MIN ){
				min = i;
				break;
			}
		}
		for(j=i+1;j<4;j++){
			//　現在の境界はスキップ //
			if(j != l10){
				if(tau_n[j] < tau_n[min] && tau_n[j] >= VEC_MIN ){
					min = j;
				}
			}
		}
		l10 = min;
		tmin = tau_n[min];

		return tmin;
	}

	void search(void) {
		// 0除算回避
		if(c_fabs(alpha_y[w10]) < VEC_MIN){
			tau_n[0] = -x10/alpha_x[w10];
			tau_n[1] = 0.0;
			tau_n[2] = -z10/alpha_z[w10];
			tau_n[3] = 0.0;
		}
		else {
			y_1tmp = 1.0-y10;
			tau_n[0] = -x10/alpha_x[w10];
			tau_n[1] = -y10/alpha_y[w10];
			tau_n[2] = -z10/alpha_z[w10];
			tau_n[3] = y_1tmp/alpha_y[w10];
		}

		// 正の時間が見つからない場合終了 //
		if(tau_n[0] <   VEC_MIN &&tau_n[1] < VEC_MIN &&tau_n[2] < VEC_MIN &&tau_n[3]< VEC_MIN){			
		}

		// 最小の時間を探す //
		tau_1 = sort(tau_n);
		tau_1_tmp = tau_1;
		state = STATE_IN_VECTOR;
	}

	void set_next_boundary(void)
	{
		if(l10==0) x11 = 0.0;
		else if(l10==1) y11 = 0.0;
		else if(l10==2) z11 = 0.0;
		else if(l10==3) y11 = 1.0;

		// 次のw10を決定 //
		if(l10==0){
			if(alpha_x[w10] < VEC_MIN ){
				l11 = -1;
			}
			else
				l11 = 1;
		}
		if(l10==1||l10==3){
			if(alpha_y[w10] < VEC_MIN)
				l11 = -2;
			else
				l11 = 2;
		}
		if(l10==2){
			if(alpha_z[w10] < VEC_MIN)
				l11 = -6;
			else
				l11 = 6;
		}

		w11 = w10 + l11;
		w10 = w11;
	}

	void update_vector(float param1, float param2){
		// b = 0.1 + (0.5 - 0.1) * param2;
		a = 1.5;
		b = 0.38;
		alpha_y[0] = 1.0+b;
		alpha_y[1] = -1.0+b;
		alpha_y[2] = 1.0-b;
		alpha_y[3] = -1.0-b;
		alpha_y[4] = 1.0-b;
		alpha_y[5] = -1.0-b;
		alpha_y[6] = 1.0+b-a;
		alpha_y[7] = -1.0+b-a;
		alpha_y[8] = 1.0-b+a;
		alpha_y[9] = -1.0-b+a;
		alpha_y[10] = 1.0-b+a;
		alpha_y[11] = -1.0-b+a;

		if(c_fabs(alpha_y[w10]) < VEC_MIN){
			tau_n[0] = -x11/alpha_x[w10];
			tau_n[1] = 0.0;
			tau_n[2] = -z11/alpha_z[w10];
			tau_n[3] = 0.0;
		}
		else {
			y_1tmp = 1.0-y11;
			tau_n[0] = -x11/alpha_x[w10];
			tau_n[1] = -y11/alpha_y[w10];
			tau_n[2] = -z11/alpha_z[w10];
			tau_n[3] = y_1tmp/alpha_y[w10];
		}

		tau_1 = sort(tau_n);
		tau_1_tmp = tau_1;
		// tau_d = tau_1 * param1 * TIME_SCALE + 0.001; 
		tau_d = tau_1 * TIME_SCALE;

	}
	
  };
  
  /*===========================================================================*/
  /* Lifecycle Methods. */
  /*===========================================================================*/

  Effect(void) {}
  ~Effect(void) {} // Note: will never actually be called for statically allocated instances

  inline int8_t Init(const unit_runtime_desc_t * desc) {
    if (!desc)
      return k_unit_err_undef;
    
    // Note: make sure the unit is being loaded to the correct platform/module target
    if (desc->target != unit_header.common.target)
      return k_unit_err_target;
    
    // Note: check API compatibility with the one this unit was built against
    if (!UNIT_API_IS_COMPAT(desc->api))
      return k_unit_err_api_version;
    
    // Check compatibility of samplerate with unit, for NTS-3 kaoss pad kit should be 48000
    if (desc->samplerate != 48000)
      return k_unit_err_samplerate;

    // Check compatibility of frame geometry
    if (desc->input_channels != 2 || desc->output_channels != 2)  // should be stereo input/output
      return k_unit_err_geometry;

    // If SDRAM buffers are required they must be allocated here
    if (!desc->hooks.sdram_alloc)
      return k_unit_err_memory;
    float *m = (float *)desc->hooks.sdram_alloc(BUFFER_LENGTH*sizeof(float));
    if (!m)
      return k_unit_err_memory;

    // Make sure memory is cleared
    buf_clr_f32(m, BUFFER_LENGTH);
    
    allocated_buffer_ = m;

    // Cache the runtime descriptor for later use
    runtime_desc_ = *desc;

    // Make sure parameters are reset to default values
    params_.reset();

	chaos_.amp = 0.0;
	chaos_.state = chaos_.STATE_INIT;
	params_.param1 = 0.5;
	params_.param2 = 0.5;
	params_.depth = 0.0;
	params_.param4 = 0;

    return k_unit_err_none;
  }

  inline void Teardown() {
    // Note: buffers allocated via sdram_alloc are automatically freed after unit teardown
    // Note: cleanup and release resources if any
    allocated_buffer_ = nullptr;
  }

  inline void Reset() {
	
    // Note: Reset effect state, excluding exposed parameter values.
	chaos_.gain_update = GAIN_UP;
  }

  inline void Resume() {
    // Note: Effect will resume and exit suspend state. Usually means the synth
    // was selected and the render callback will be called again

    // Note: If it is required to clear large memory buffers, consider setting a flag
    //       and trigger an asynchronous progressive clear on the audio thread (Process() handler)
  }

  inline void Suspend() {
    // Note: Effect will enter suspend state. Usually means another effect was
    // selected and thus the render callback will not be called
	chaos_.gain_update = GAIN_DOWN;
  }

  /*===========================================================================*/
  /* Other Public Methods. */
  /*===========================================================================*/

  fast_inline void Process(const float * in, float * out, size_t frames) {
	
    const float * __restrict in_p = in;
    float * __restrict out_p = out;
    const float * out_e = out_p + (frames << 1);  // assuming stereo output

    // Caching current parameter values. Consider interpolating sensitive parameters.
    // const Params p = params_;

	if(chaos_.state == chaos_.STATE_INIT)
	{
		chaos_.a = 1.5;
		chaos_.b = 0.5;
		chaos_.alpha_x[0] = -1.0;	chaos_.alpha_z[0] = 1.0; 		chaos_.alpha_y[0] = 1.0+chaos_.b;
		chaos_.alpha_x[1] = -1.0; 	chaos_.alpha_z[1] = -1.0;		chaos_.alpha_y[1] = -1.0+chaos_.b;
		chaos_.alpha_x[2] = -1.0; 	chaos_.alpha_z[2] = 1.0;		chaos_.alpha_y[2] = 1.0-chaos_.b;
		chaos_.alpha_x[3] = -1.0; 	chaos_.alpha_z[3] = -1.0;		chaos_.alpha_y[3] = -1.0-chaos_.b;
		chaos_.alpha_x[4] =  1.0; 	chaos_.alpha_z[4] = 1.0;		chaos_.alpha_y[4] = 1.0-chaos_.b;
		chaos_.alpha_x[5] =  1.0; 	chaos_.alpha_z[5] = -1.0;		chaos_.alpha_y[5] = -1.0-chaos_.b;
		chaos_.alpha_x[6] = -1.0;	chaos_.alpha_z[6] = 1.0;		chaos_.alpha_y[6] = 1.0+chaos_.b-chaos_.a;
		chaos_.alpha_x[7] = -1.0; 	chaos_.alpha_z[7] = -1.0;		chaos_.alpha_y[7] = -1.0+chaos_.b-chaos_.a;
		chaos_.alpha_x[8] = -1.0; 	chaos_.alpha_z[8] = 1.0;		chaos_.alpha_y[8] = 1.0-chaos_.b+chaos_.a;
		chaos_.alpha_x[9] = -1.0; 	chaos_.alpha_z[9] = -1.0;		chaos_.alpha_y[9] = -1.0-chaos_.b+chaos_.a;
		chaos_.alpha_x[10] = 1.0;	chaos_.alpha_z[10] = 1.0;		chaos_.alpha_y[10] = 1.0-chaos_.b+chaos_.a;
		chaos_.alpha_x[11] = 1.0; 	chaos_.alpha_z[11] = -1.0;		chaos_.alpha_y[11] = -1.0-chaos_.b+chaos_.a;	

		chaos_.x10 = 0.5;

		chaos_.y10 = 0.2;
		chaos_.z10 = -0.5;
		chaos_.first_point(chaos_.x10, chaos_.y10, chaos_.z10);

		if (chaos_.c_fabs(chaos_.alpha_y[chaos_.w10]) < VEC_MIN) {
			chaos_.tau_n[0] = -chaos_.x10 / chaos_.alpha_x[chaos_.w10];
			chaos_.tau_n[1] = 0.0;
			chaos_.tau_n[2] = -chaos_.z10 / chaos_.alpha_z[chaos_.w10];
			chaos_.tau_n[3] = 0.0;
		}
		else {
			chaos_.y_1tmp = 1.0 - chaos_.y10;
			chaos_.tau_n[0] = -chaos_.x10 / chaos_.alpha_x[chaos_.w10];
			chaos_.tau_n[1] = -chaos_.y10 / chaos_.alpha_y[chaos_.w10];
			chaos_.tau_n[2] = -chaos_.z10 / chaos_.alpha_z[chaos_.w10];
			chaos_.tau_n[3] = chaos_.y_1tmp / chaos_.alpha_y[chaos_.w10];
		}

		// 最小の時間を探す //
		chaos_.tau_1 = chaos_.sort(chaos_.tau_n);
		
		// chaos_.tau_d = chaos_.tau_1 * TIME_SCALE;	
		chaos_.tau_d = chaos_.tau_1 * params_.param1 * TIME_SCALE;	
		chaos_.state = chaos_.STATE_IN_VECTOR;

		chaos_.tar_x = chaos_.x10 + chaos_.tau_1 * chaos_.alpha_x[chaos_.w10];
		chaos_.tar_y = chaos_.y10 + chaos_.tau_1 * chaos_.alpha_y[chaos_.w10];
		chaos_.tar_z = chaos_.z10 + chaos_.tau_1 * chaos_.alpha_z[chaos_.w10];

	}

	float wet1, wet2;
	float out1, out2;
	float mix;

    for (; out_p != out_e; in_p += 2, out_p += 2) {
      // Process samples here
	  // 解を計算 //

		chaos_.x_tmp = chaos_.tau_d * chaos_.alpha_x[chaos_.w10];
		chaos_.y_tmp = chaos_.tau_d * chaos_.alpha_y[chaos_.w10];
		chaos_.z_tmp = chaos_.tau_d * chaos_.alpha_z[chaos_.w10];

		chaos_.x11 = chaos_.x10 + chaos_.x_tmp;
		chaos_.y11 = chaos_.y10 + chaos_.y_tmp;
		chaos_.z11 = chaos_.z10 + chaos_.z_tmp;

		chaos_.tau_1 -= chaos_.tau_d;
		// 境界二衝突
		if(chaos_.tau_1 <= VEC_MIN) {

			chaos_.x11 = chaos_.tar_x;
			chaos_.y11 = chaos_.tar_y;
			chaos_.z11 = chaos_.tar_z;

			// chaos_.state = chaos_.STATE_ON_BOUNDARY;	
			// 次の境界を決定
			if (chaos_.l10 == 0) chaos_.x11 = 0.0;
			else if (chaos_.l10 == 1) chaos_.y11 = 0.0;
			else if (chaos_.l10 == 2) chaos_.z11 = 0.0;
			else if (chaos_.l10 == 3) chaos_.y11 = 1.0;

			// 次のw10を決定 //
			if (chaos_.l10 == 0) {
				if (chaos_.alpha_x[chaos_.w10] < VEC_MIN) {
					chaos_.l11 = -1;
				}
				else
					chaos_.l11 = 1;
			}
			if (chaos_.l10 == 1 || chaos_.l10 == 3) {
				if (chaos_.alpha_y[chaos_.w10] < VEC_MIN)
					chaos_.l11 = -2;
				else
					chaos_.l11 = 2;
			}
			if (chaos_.l10 == 2) {
				if (chaos_.alpha_z[chaos_.w10] < VEC_MIN)
					chaos_.l11 = -6;
				else
					chaos_.l11 = 6;
			}

			chaos_.w11 = chaos_.w10 + chaos_.l11;

			chaos_.w10 = chaos_.w11;
			// update vector field
			// chaos_.set_next_boundary();
			// chaos_.update_vector(params_.param1, params_.param2);

			chaos_.b = 0.1 + (0.5 - 0.1) * params_.param2;

			chaos_.alpha_x[0] = -1.0;	chaos_.alpha_z[0] = 1.0; 		chaos_.alpha_y[0] = 1.0+chaos_.b;
			chaos_.alpha_x[1] = -1.0; 	chaos_.alpha_z[1] = -1.0;		chaos_.alpha_y[1] = -1.0+chaos_.b;
			chaos_.alpha_x[2] = -1.0; 	chaos_.alpha_z[2] = 1.0;		chaos_.alpha_y[2] = 1.0-chaos_.b;
			chaos_.alpha_x[3] = -1.0; 	chaos_.alpha_z[3] = -1.0;		chaos_.alpha_y[3] = -1.0-chaos_.b;
			chaos_.alpha_x[4] =  1.0; 	chaos_.alpha_z[4] = 1.0;		chaos_.alpha_y[4] = 1.0-chaos_.b;
			chaos_.alpha_x[5] =  1.0; 	chaos_.alpha_z[5] = -1.0;		chaos_.alpha_y[5] = -1.0-chaos_.b;
			chaos_.alpha_x[6] = -1.0;	chaos_.alpha_z[6] = 1.0;		chaos_.alpha_y[6] = 1.0+chaos_.b-chaos_.a;
			chaos_.alpha_x[7] = -1.0; 	chaos_.alpha_z[7] = -1.0;		chaos_.alpha_y[7] = -1.0+chaos_.b-chaos_.a;
			chaos_.alpha_x[8] = -1.0; 	chaos_.alpha_z[8] = 1.0;		chaos_.alpha_y[8] = 1.0-chaos_.b+chaos_.a;
			chaos_.alpha_x[9] = -1.0; 	chaos_.alpha_z[9] = -1.0;		chaos_.alpha_y[9] = -1.0-chaos_.b+chaos_.a;
			chaos_.alpha_x[10] = 1.0;	chaos_.alpha_z[10] = 1.0;		chaos_.alpha_y[10] = 1.0-chaos_.b+chaos_.a;
			chaos_.alpha_x[11] = 1.0; 	chaos_.alpha_z[11] = -1.0;		chaos_.alpha_y[11] = -1.0-chaos_.b+chaos_.a;	


			if (fabs(chaos_.alpha_y[chaos_.w10]) < VEC_MIN) {
				chaos_.tau_n[0] = -chaos_.x11 / chaos_.alpha_x[chaos_.w10];
				chaos_.tau_n[1] = 0.0;
				chaos_.tau_n[2] = -chaos_.z11 / chaos_.alpha_z[chaos_.w10];
				chaos_.tau_n[3] = 0.0;
			}
			else {
				chaos_.y_1tmp = 1.0 - chaos_.y11;
				chaos_.tau_n[0] = -chaos_.x11 / chaos_.alpha_x[chaos_.w10];
				chaos_.tau_n[1] = -chaos_.y11 / chaos_.alpha_y[chaos_.w10];
				chaos_.tau_n[2] = -chaos_.z11 / chaos_.alpha_z[chaos_.w10];
				chaos_.tau_n[3] = chaos_.y_1tmp / chaos_.alpha_y[chaos_.w10];
			}

			// 最小の時間を探す //
			chaos_.tau_1 = chaos_.sort(chaos_.tau_n);
		
			// chaos_.tau_d = chaos_.tau_1 * TIME_SCALE;	
			chaos_.tau_d = chaos_.tau_1 * params_.param1 * TIME_SCALE;
			chaos_.state = chaos_.STATE_IN_VECTOR;
			// chaos_.tau_1 = 0.f;
			// 境界までの時間を再探索
			chaos_.tar_x = chaos_.x11 + chaos_.tau_1 * chaos_.alpha_x[chaos_.w10];
			chaos_.tar_y = chaos_.y11 + chaos_.tau_1 * chaos_.alpha_y[chaos_.w10];
			chaos_.tar_z = chaos_.z11 + chaos_.tau_1 * chaos_.alpha_z[chaos_.w10];
		}

      // Note: this is a dummy unit only to demonstrate APIs, only passing through audio
	  // morph
	//    if (params_.depth <= 0.5) {
    //     // チャンネル1: x -> x (変化なし), チャンネル2: y -> z (補間)
    //     out1 = chaos_.x11;  // x は変化なし
    //     out2 = chaos_.y11 * (1.f - 2.f * params_.depth) + chaos_.z11 * (2.f * params_.depth);  // y から z への補間
    // 	} else {
    //     // チャンネル1: x -> y (補間), チャンネル2: z -> z (変化なし)
    //     out1 = chaos_.x11 * (2.f - 2.f * params_.depth) + chaos_.y11 * (2.f * params_.depth - 1.f);  // x から y への補間
    //     out2 = chaos_.z11;  // z は変化なし
    // 	}
	if(params_.param4 == 0) {
		wet1 = chaos_.x11;
		wet2 = chaos_.y11;
	} else if(params_.param4 == 1) {
		wet1 = chaos_.x11;
		wet2 = chaos_.z11;
	} else if(params_.param4 == 2) {
		wet1 = chaos_.y11;
		wet2 = chaos_.z11;
	} else {
		wet1 = chaos_.x11;
		wet2 = chaos_.y11;
	}

	mix = 0.5 * (1 + params_.depth);

    // DRY/WETバランスを調整
    out1 = in_p[0] * (1.f - mix) + wet1 * mix;
    out2 = in_p[1] * (1.f - mix) + wet2 * mix;


	out_p[0] = CLIP(((out1 ) * chaos_.amp), -1.f, 1.f); // left sample
	out_p[1] = CLIP(((out2 ) * chaos_.amp), -1.f, 1.f); // right sample

		chaos_.amp += chaos_.gain_update;
		if(chaos_.amp >= GAIN_SCALE) {
			chaos_.gain_update = GAIN_SUSTAIN;
			chaos_.amp = GAIN_SCALE;
		} else if(chaos_.amp < 0.0f) {
			chaos_.gain_update = GAIN_SUSTAIN;
			chaos_.amp = 0.0f;
		}
		chaos_.x10 = chaos_.x11;
		chaos_.y10 = chaos_.y11;
		chaos_.z10 = chaos_.z11;
    }

  }

  inline void setParameter(uint8_t index, int32_t value) {
    switch (index) {
    case PITCH:
      // 10bit 0-1023 parameter
      value = clipminmaxi32(48, value, 1023);
      params_.param1 = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
      break;

    case CHAOS:
      // 10bit 0-1023 parameter
      value = clipminmaxi32(0, value, 1023);
      params_.param2 = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
      break;

    case DEPTH:
      // Single digit base-10 fractional value, bipolar dry/wet
      value = clipminmaxi32(-1000, value, 1000);
      params_.depth = value / 1000.f; // -100.0 .. 100.0 -> -1.0 .. 1.0
      break;
    case PARAM4:
      // strings type parameter, receiving index value
 	  value = clipminmaxi32(PARAM4_VALUE0, value, NUM_PARAM4_VALUES-1);
      params_.param4 = value;
      break;
      
    default:
      break;
    }
  }

  inline int32_t getParameterValue(uint8_t index) const {
    switch (index) {
    case PITCH:
      // 10bit 0-1023 parameter
      return param_f32_to_10bit(params_.param1);
      break;

    case CHAOS:
      // 10bit 0-1023 parameter
      return param_f32_to_10bit(params_.param2);
      break;

    case DEPTH:
      // Single digit base-10 fractional value, bipolar dry/wet
      return (int32_t)(params_.depth * 1000);
      break;

    case PARAM4:
      // strings type parameter, return index value
      return params_.param4;
      
    default:
      break;
    }

    return INT_MIN; // Note: will be handled as invalid
  }

  inline const char * getParameterStrValue(uint8_t index, int32_t value) const {
    // Note: String memory must be accessible even after function returned.
    //       It can be assumed that caller will have copied or used the string
    //       before the next call to getParameterStrValue
    
    static const char * param4_strings[NUM_PARAM4_VALUES] = {
      "X-Y",
      "X-Z",
      "Y-Z",
    };
    
    switch (index) {
    case PARAM4:
      if (value >= PARAM4_VALUE0 && value < NUM_PARAM4_VALUES)
        return param4_strings[value];
      break;
    default:
      break;
    }
    
    return nullptr;
  }
  
  inline void setTempo(uint32_t tempo) {
    // const float bpmf = (tempo >> 16) + (tempo & 0xFFFF) / static_cast<float>(0x10000);
    (void)tempo;
  }

  inline void tempo4ppqnTick(uint32_t counter) {
    (void)counter;
  }

  inline void touchEvent(uint8_t id, uint8_t phase, uint32_t x, uint32_t y) {
    // Note: Touch x/y events are already mapped to specific parameters so there is usually there no need to set parameters from here.
    //       Audio source type effects, for instance, may require these events to trigger enveloppes and such.
    
    (void)id;
    (void)x;
    (void)y;
    
    switch (phase) {
    case k_unit_touch_phase_began:
	  Effect::Reset();
	  
      break;
    case k_unit_touch_phase_moved:
      break;
    case k_unit_touch_phase_ended:
	  Effect::Suspend();
      break;  
    case k_unit_touch_phase_stationary:
      break;
    case k_unit_touch_phase_cancelled:
      break; 
    default:
      break;
    }
  }
 
  /*===========================================================================*/
  /* Static Members. */
  /*===========================================================================*/
  
 private:
  /*===========================================================================*/
  /* Private Member Variables. */
  /*===========================================================================*/

  std::atomic_uint_fast32_t flags_;

  unit_runtime_desc_t runtime_desc_;

  Params params_;

  Chaos chaos_;
  
  float * allocated_buffer_;
  
  /*===========================================================================*/
  /* Private Methods. */
  /*===========================================================================*/

  /*===========================================================================*/
  /* Constants. */
  /*===========================================================================*/
};
