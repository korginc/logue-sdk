#pragma once

#include "utils/float_math.h"   // for M_TWOPI

// Templated on number of oscillators
template <unsigned N>
struct OscillatorBank
{
public:

    void setFundamentalFrequency(const float f0)
    {
        for(unsigned n=0; n<N; ++n)
            oscillators_[n].setFrequency((n+1) * f0);

    };

    float* process()
    {
        static float osc_outputs[N];

        for(unsigned n=0; n<N; ++n)
            osc_outputs[n] = norm_gain_ * oscillators_[n].process();

        return osc_outputs;
    };

    void reset()
    {
     for (auto osc : oscillators_)
        osc.reset();
    };

private:

    class SineOsc
    {
    public:

        void setFrequency(const float frequency) 
        {
            const float theta = M_TWOPI * frequency * m_sampling_period; // 2*pi*freq/SR
            
            m_x1 = cos(theta);
            m_y1 = sin(theta);
        };

        float process()
        {
            const float x = m_x1 * m_last_x - m_y1 * m_last_y;
            const float y = m_y1 * m_last_x + m_x1 * m_last_y;
            
            m_last_x = x;
            m_last_y = y;
            
            return x;
        };

        void reset()
        {
            m_last_x = 0.f;
            m_last_y = 1.f;
        };
        
    private:
        
        static constexpr float m_sampling_period{1.f / 48000.f};

        float m_x1{0};
        float m_y1{0};
        float m_last_x{0};
        float m_last_y{1};
    };

    SineOsc oscillators_[N];
    static constexpr float norm_gain_{1.f / N}; // Scales each resonator by 1/N

};