unisaw
--------------------
Parameter 1: Spread
controls the frequency spread of all 7 oscillators, higher value result in more beating effect

Parameter 2: Mix
controls the volume of 6 side oscillators

Parameter 3: Noise
all oscillators FM 'ed by low-pass filtered white noise

Parameter 4: Algorithm
select saw wave algorithm: naive(default), polyBLEP, wavetable (aliasing amount from highest to lowest)

Tips: experiment with different saw algorithms to see what you prefer, some folks like the fat saw lead of JP8000 due to its aliasing digital oscllators
