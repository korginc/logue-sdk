## x-to-note Oscillator

This is a sample for converting the X-axis value of a touchpad to a note and generating an OSC (Oscillator) sound. The API is consolidated in `note_api.h`, so by including it and simply calling the API, you can convert values from 0-1023 to notes.

**Note**: Parameters for converting to notes need to be given within the range of 0-1023.

### Unit Description

**Assigned Parameters**

- **X**: Note
- **DEPTH**: Wet Level

### Parameters Accessible from EDIT

- **SCALE**: Chromatic, Lydian, Dorian, Ionian, Major Pentatonic, Minor Pentatonic
- **MIN**: Note when the X value is the lowest (# is represented by ', for example, C'4 means C#4)
- **MAX**: Note when the X value is the highest

-------------------------------------------------------------------------------------------------------------------

## x-to-note Oscillator

タッチパッドのX軸の値をノートに変換しOSCを鳴らすサンプルです。  
note_api.hにAPIはまとまっているので、インクルードしてAPIを呼び出すだけで0-1023の値をノートに変換することができます。  
※ノートに変換するパラメータは0-1023の範囲で与える必要があります。

### ユニットの説明

**アサインされたパラメータ**

- **X**: ノート
- **DEPTH**: Wet Level

### EDITからアクセスするパラメータ

- **SCALE**: Chromatic、Lydian、Dorian、Ionian、Major Pentatonic、Minor Pentatonic
- **MIN**: Xの値が最も低い時のノート (C-1 ~ G9、#は'で表し、例えばC'4はC#4)
- **MAX**: Xの値が最も高い時のノート (C-1 ~ G9)

---