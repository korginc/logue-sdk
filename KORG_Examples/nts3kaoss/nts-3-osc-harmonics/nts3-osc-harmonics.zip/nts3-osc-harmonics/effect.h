#pragma once
/*
    BSD 3-Clause License

    Copyright (c) 2023, KORG INC.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

//*/

/*
 *  File: effect.h
 *
 *  Dummy generic effect template instance.
 *
 */

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <climits>

#include "unit_genericfx.h"   // Note: Include base definitions for genericfx units
#include "oscillator_bank.h"

#include "utils/buffer_ops.h" // for buf_clr_f32()
#include "utils/int_math.h"   // for clipminmaxi32()
#include "fx_api.h"    // for fx_white()

class Effect {
 public:
  /*===========================================================================*/
  /* Public Data Structures/Types/Enums. */
  /*===========================================================================*/

  enum {
    NOTE_MIN = 12,
    NOTE_MAX = 72
  };

  enum {
    GATE_MODE = 0,
    FREE_MODE = 1,
    AUTO_MODE = 2
  };

  enum {
    NUMBER_OF_OSCILLATORS = 8
  };

  enum {
    BUFFER_LENGTH = 0x40000 
  };

  enum {
    SCAN = 0U,
    WIDTH,
    PITCH, 
    MODE,
    SHLFORATE,
    SHLFODEPTH,
    NUM_PARAMS
  };

  // Note: Make sure that default param values correspond to declarations in header.c
  struct Params {
    float param1{0.f};
    float param2{0.f};
    uint32_t param3{24}; // CHECK DEFAULT!!!
    uint32_t param4{0};
    float param5{0.f};
    float param6{0.f};

    void reset() {
      param1 = 0.f;
      param2 = 0.f;
      param3 = 0;
      param4 = 0;
      param5 = 0.f;
      param6 = 0.f;
    }
  };
  
  /*===========================================================================*/
  /* Lifecycle Methods. */
  /*===========================================================================*/

  Effect(void) {}
  ~Effect(void) {} // Note: will never actually be called for statically allocated instances

  inline int8_t Init(const unit_runtime_desc_t * desc) {
    if (!desc)
      return k_unit_err_undef;
    
    // Note: make sure the unit is being loaded to the correct platform/module target
    if (desc->target != unit_header.common.target)
      return k_unit_err_target;
    
    // Note: check API compatibility with the one this unit was built against
    if (!UNIT_API_IS_COMPAT(desc->api))
      return k_unit_err_api_version;
    
    // Check compatibility of samplerate with unit, for NTS-3 kaoss pad kit should be 48000
    if (desc->samplerate != 48000)
      return k_unit_err_samplerate;

    // Check compatibility of frame geometry
    if (desc->input_channels != 2 || desc->output_channels != 2)  // should be stereo input/output
      return k_unit_err_geometry;

    // If SDRAM buffers are required they must be allocated here
    if (!desc->hooks.sdram_alloc)
      return k_unit_err_memory;
    float *m = (float *)desc->hooks.sdram_alloc(BUFFER_LENGTH*sizeof(float));
    if (!m)
      return k_unit_err_memory;

    // Make sure memory is cleared
    buf_clr_f32(m, BUFFER_LENGTH);
    
    allocated_buffer_ = m;

    // Cache the runtime descriptor for later use
    runtime_desc_ = *desc;

    // Make sure parameters are reset to default values
    params_.reset();

    osc_bank_.reset();    
    return k_unit_err_none;
  }

  inline void Teardown() {
    // Note: buffers allocated via sdram_alloc are automatically freed after unit teardown
    // Note: cleanup and release resources if any
    allocated_buffer_ = nullptr;
  }

  inline void Reset() {

    for (auto gain : smoothed_osc_gains_)
      gain = 0.f;

    osc_bank_.reset();

    if (params_.param4 == GATE_MODE)
    {
      smoothed_global_gain_ = 0.f;
      global_gain_ = 1.f;
    }
    if ((params_.param4 == FREE_MODE) || (params_.param4 == AUTO_MODE))
    {
      smoothed_global_gain_ = 1.f;
      global_gain_ = 1.f;
    }

  }

  inline void Resume() {
    // Note: Effect will resume and exit suspend state. Usually means the synth
    // was selected and the render callback will be called again

    // Note: If it is required to clear large memory buffers, consider setting a flag
    //       and trigger an asynchronous progressive clear on the audio thread (Process() handler)
  }

  inline void Suspend() {
    // Note: Effect will enter suspend state. Usually means another effect was
    // selected and thus the render callback will not be called

    if (params_.param4 == 0)
      global_gain_ = 0.f;
  }

  /*===========================================================================*/
  /* Other Public Methods. */
  /*===========================================================================*/


  float ComputeOscillatorGain(const int idx) {

    const float x{(float) idx };
    const float width{NUMBER_OF_OSCILLATORS - 1.f + params_.param2};
    const float scan{(NUMBER_OF_OSCILLATORS - 1.f) * params_.param1};
    const float gain = -(NUMBER_OF_OSCILLATORS - width) * (x - scan) * (x - scan) + 1.f;

    return clip01f(gain);
  }

  class TriggerLFO
  {
  public:
    void SetFrequency(const float frequency)
    {
      step_ = frequency * sample_period_;
    }

    bool Process()
    {
      counter_state_ += step_;

      hold_state_ = false;
      if (counter_state_ > 1.f)
      {
        counter_state_ -= 1.f;
        hold_state_ = true;
      }

      return hold_state_;

    }
  
    void Reset()
    {
      hold_state_ = 0.f;
      counter_state_ = 0.f;
    }
  
  private:

    static constexpr float sample_period_{1.f / 48e3f};
    float counter_state_{0};
    float step_{0};
    float hold_state_{0};

  };


  fast_inline void Process(const float * in, float * out, size_t frames) {
    const float * __restrict in_p = in;
    float * __restrict out_p = out;
    const float * out_e = out_p + (frames << 1);  // assuming stereo output

    for (; out_p != out_e; in_p += 2, out_p += 2) {
      // Process samples here
      
      osc_bank_.setFundamentalFrequency(osc_notehzf(params_.param3));

      float* osc_bank_output = osc_bank_.process();
      
      // AUTO MODE
      if (params_.param4 == AUTO_MODE)
      {
        // ADD RANDOM MODULATION (S/H-STYLE)
        const float mod_freq{(lfo_max_freq_ - lfo_min_freq_) * params_.param5 + lfo_min_freq_};

        trigger_lfo.SetFrequency(mod_freq);

        if (trigger_lfo.Process())
            params_.param1 = clip01f(0.5f * fx_white() + 0.5f);
      }

      smoothed_global_gain_ = linintf(smoothing_coeff_, smoothed_global_gain_, global_gain_);

      // RUN OSCILLATORS
      float output_signal{0};
      float osc_gain_mask[NUMBER_OF_OSCILLATORS];
      for (unsigned n=0; n<NUMBER_OF_OSCILLATORS; ++n)
      {
        osc_gain_mask[n] = ComputeOscillatorGain(n);
        smoothed_osc_gains_[n] = linintf(smoothing_coeff_, smoothed_osc_gains_[n], osc_gain_mask[n]);
        output_signal += (smoothed_osc_gains_[n] * osc_bank_output[n]);
      }

      out_p[0] = smoothed_global_gain_ * output_signal; // left sample
      out_p[1] = smoothed_global_gain_ * output_signal; // right sample
    }
  }

  inline void setParameter(uint8_t index, int32_t value) {
    switch (index) {
    case SCAN:
      // 10bit 0-1023 parameter
      if (params_.param4 != AUTO_MODE) // Quick trick to disable x-axis during "Auto Mode"
      {
        value = clipminmaxi32(0, value, 1023);
        params_.param1 = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
      }
      break;

    case WIDTH:
      // 10bit 0-1023 parameter
      value = clipminmaxi32(0, value, 1023);
      params_.param2 = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
      break;

    case PITCH:
      // strings type parameter, receiving index value
      value = clipminmaxi32(NOTE_MIN, value, NOTE_MAX);
      params_.param3 = value;
      break;
      
    case MODE:
      // strings type parameter, receiving index value
      value = clipminmaxi32(GATE_MODE, value, AUTO_MODE);
      params_.param4 = value;
      break;

    case SHLFORATE:
      // 10bit 0-1023 parameter
      value = clipminmaxi32(0, value, 1023);
      params_.param5 = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
      break;

    default:
      break;
    }
  }

  inline int32_t getParameterValue(uint8_t index) const {
    switch (index) {
    case SCAN:
      // 10bit 0-1023 parameter
      return param_f32_to_10bit(params_.param1);
      break;

    case WIDTH:
      // 10bit 0-1023 parameter
      return param_f32_to_10bit(params_.param2);
      break;

    case PITCH:
      return params_.param3;
      break;

    case MODE:
      return params_.param4;
      break;

    case SHLFORATE:
      return param_f32_to_10bit(params_.param5);

    default:
      break;
    }

    return INT_MIN; // Note: will be handled as invalid
  }

  inline const char * getParameterStrValue(uint8_t index, int32_t value) const {
    // Note: String memory must be accessible even after function returned.
    //       It can be assumed that caller will have copied or used the string
    //       before the next call to getParameterStrValue

    static const char *noteNames[NOTE_MAX] = {
        "C0", "C'0", "D0", "D'0", "E0", "F0", "F'0", "G0", "G'0", "A0", "A'0", "B0",
        "C1", "C'1", "D1", "D'1", "E1", "F1", "F'1", "G1", "G'1", "A1", "A'1", "B1",
        "C2", "C'2", "D2", "D'2", "E2", "F2", "F'2", "G2", "G'2", "A2", "A'2", "B2",
        "C3", "C'3", "D3", "D'3", "E3", "F3", "F'3", "G3", "G'3", "A3", "A'3", "B3",
        "C4", "C'4", "D4", "D'4", "E4", "F4", "F'4", "G4", "G'4", "A4", "A'4", "B4"
    };

    static const char *modeNames[3] = {"GATE", "FREE", "AUTO"};

    switch (index) {
    case PITCH:
      if (value >= NOTE_MIN && value < NOTE_MAX)
        return noteNames[value];
		  break;
    case MODE:
        return modeNames[value];
		  break;
    default:
      break;
    }
    
    return nullptr;
  }
  
  inline void setTempo(uint32_t tempo) {
    // const float bpmf = (tempo >> 16) + (tempo & 0xFFFF) / static_cast<float>(0x10000);
    (void)tempo;
  }

  inline void tempo4ppqnTick(uint32_t counter) {
    (void)counter;
  }

  inline void touchEvent(uint8_t id, uint8_t phase, uint32_t x, uint32_t y) {
    // Note: Touch x/y events are already mapped to specific parameters so there is usually there no need to set parameters from here.
    //       Audio source type effects, for instance, may require these events to trigger enveloppes and such.
    
    (void)id;
    (void)phase;
    (void)x;
    (void)y;
    
    switch (phase) {
    case k_unit_touch_phase_began:
      Effect::Reset();
      break;
    case k_unit_touch_phase_moved:
      break;
    case k_unit_touch_phase_ended:
  	  Effect::Suspend();
      break;  
    case k_unit_touch_phase_stationary:
      break;
    case k_unit_touch_phase_cancelled:
      break; 
    default:
      break;
    }
  }
  
  /*===========================================================================*/
  /* Static Members. */
  /*===========================================================================*/
  
 private:
  /*===========================================================================*/
  /* Private Member Variables. */
  /*===========================================================================*/

  static constexpr float smoothing_coeff_{0.004f};

  // Smoother states
  float smoothed_osc_gains_[NUMBER_OF_OSCILLATORS];
  float smoothed_global_gain_;
  float global_gain_;

  std::atomic_uint_fast32_t flags_;

  unit_runtime_desc_t runtime_desc_;

  Params params_;
  
  float * allocated_buffer_;

  OscillatorBank<NUMBER_OF_OSCILLATORS> osc_bank_;

  static constexpr float lfo_max_freq_{20.f};
  static constexpr float lfo_min_freq_{0.1f};
  TriggerLFO trigger_lfo;
  
  /*===========================================================================*/
  /* Private Methods. */
  /*===========================================================================*/

  /*===========================================================================*/
  /* Constants. */
  /*===========================================================================*/
};
