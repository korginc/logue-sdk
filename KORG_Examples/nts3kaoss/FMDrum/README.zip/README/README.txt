FM Drum
--------------------
X: pitch/tone Y: FM index

Depth(slider): decay time
