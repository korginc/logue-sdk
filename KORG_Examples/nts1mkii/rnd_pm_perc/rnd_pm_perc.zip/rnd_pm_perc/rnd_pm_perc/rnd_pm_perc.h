#pragma once
/*
    BSD 3-Clause License

    Copyright (c) 2023, KORG INC.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

//*/

/*
 *  File: osc.h
 *
 *  Dummy oscillator template instance.
 *
 */

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <climits>

#include "unit_osc.h" // Note: Include base definitions for osc units

#include "utils/int_math.h" // for clipminmaxi32()

class Rnd_pm_perc
{
public:
  /*===========================================================================*/
  /* Public Data Structures/Types/Enums. */
  /*===========================================================================*/

  enum
  {
    M_DEPTH = 0U,
    RND_M_DEPTH,
    M_RATIO,
    RND_M_RATIO,
    M_DECAY,
    A_DECAY,
    RND_A_DECAY,
    P_DEPTH,
    P_DECAY,
    PM_SYNC,
  };

  const float ratio_arr[11] = {0.1f, 0.25f, 0.5f, 1.f, 2.f, 3.f, 4.f, 5.f, 6.f, 7.f, 8.f};

  const float amp_decay_coef_array[101] = {
      0,
      0.1478562,
      0.2738509,
      0.3812166,
      0.4727075,
      0.550671,
      0.6171071,
      0.6737202,
      0.7219626,
      0.7630722,
      0.7981034,
      0.8279551,
      0.853393,
      0.8750697,
      0.8935414,
      0.909282,
      0.9226952,
      0.9341252,
      0.9438652,
      0.9521651,
      0.9592377,
      0.9652647,
      0.9704005,
      0.974777,
      0.9785063,
      0.9816843,
      0.9843924,
      0.9867001,
      0.9886665,
      0.9903423,
      0.9917702,
      0.992987,
      0.993296,
      0.993399,
      0.993502,
      0.993605,
      0.993708,
      0.993811,
      0.993914,
      0.994017,
      0.99412,
      0.994223,
      0.994326,
      0.994429,
      0.994532,
      0.994635,
      0.994738,
      0.994841,
      0.994944,
      0.995047,
      0.99515,
      0.995307,
      0.995464,
      0.995621,
      0.995778,
      0.995935,
      0.996092,
      0.996249,
      0.996406,
      0.996563,
      0.99672,
      0.996877,
      0.997034,
      0.997191,
      0.997348,
      0.997505,
      0.997662,
      0.997819,
      0.997976,
      0.998133,
      0.99824,
      0.9984202,
      0.9985103,
      0.9986005,
      0.9986906,
      0.9987807,
      0.9988708,
      0.998961,
      0.9990511,
      0.9991412,
      0.9992313,
      0.9993215,
      0.9994116,
      0.9995017,
      0.9995918,
      0.999682,
      0.999712,
      0.999734,
      0.9997522,
      0.999782,
      0.9998,
      0.9998224,
      0.999836,
      0.999855,
      0.999871,
      0.9998926,
      0.999912,
      0.999937,
      0.999956,
      0.9999628,
      1,
  };

  // Note: Make sure that default param values correspond to declarations in header.c
  struct Params
  {
    int8_t pm_depth{50};
    int8_t rnd_pm_depth{50};
    int8_t pm_ratio{50};
    int8_t rnd_pm_ratio{50};
    int8_t pm_decay{80};
    int8_t amp_decay{50};
    int8_t rnd_amp_decay{50};
    int8_t pitch_mod_depth{50};
    int8_t pitch_mod_decay{30};
    int8_t sync_pm_phase{1};

    void reset()
    {
      pm_depth = 50;
      rnd_pm_depth = 50;
      pm_ratio = 50;
      rnd_pm_ratio = 50;
      pm_decay = 50;
      amp_decay = 50;
      rnd_amp_decay = 50;
      pitch_mod_depth = 50;
      pitch_mod_decay = 30;
      sync_pm_phase = 1;
    }
  };

  enum
  {
    k_flags_none = 0,
    k_flag_reset = 1 << 0,
  };

  struct State
  {
    float phase{0.f};
    float w0{440.f * k_samplerate_recipf}; // phase increment
    float w0_env{440.f * k_samplerate_recipf};
    float pm_ratio{0.1f};
    float pm_depth{0.f};
    float amp{1.f};
    float amp_decay_coef{0.99515};
    float pm_phase{0};

    std::atomic_uint_fast32_t flags{k_flags_none};

    inline void Reset(void)
    {
      phase = 0.f;
      w0 = 440.f * k_samplerate_recipf;
      w0_env = 440.f * k_samplerate_recipf;
      pm_ratio = 0.1f;
      pm_depth = 0.f;
      amp = 1.f;
      amp_decay_coef = 0.99515;
      pm_phase = 0;
      flags = k_flags_none;
    }
  };

  /*===========================================================================*/
  /* Lifecycle Methods. */
  /*===========================================================================*/

  Rnd_pm_perc(void)
  {
  }
  ~Rnd_pm_perc(void) {} // Note: will never actually be called for statically allocated instances

  inline int8_t Init(const unit_runtime_desc_t *desc)
  {
    if (!desc)
      return k_unit_err_undef;

    // Note: make sure the unit is being loaded to the correct platform/module target
    if (desc->target != unit_header.target)
      return k_unit_err_target;

    // Note: check API compatibility with the one this unit was built against
    if (!UNIT_API_IS_COMPAT(desc->api))
      return k_unit_err_api_version;

    // Check compatibility of samplerate with unit, for NTS-1 MKII should be 48000
    if (desc->samplerate != 48000)
      return k_unit_err_samplerate;

    // Check compatibility of frame geometry
    // Note: NTS-1 mkII oscillators can make use of the audio input depending on the routing options in global settings, see product documentation for details.
    if (desc->input_channels != 2 || desc->output_channels != 1) // should be stereo input / mono output
      return k_unit_err_geometry;

    // Note: SDRAM is not available from the oscillator runtime environment

    // Cache the runtime descriptor for later use
    runtime_desc_ = *desc;

    // Make sure parameters are reset to default values
    params_.reset();

    return k_unit_err_none;
  }

  inline void Teardown()
  {
    // Note: cleanup and release resources if any
  }

  inline void Reset()
  {
    // Note: Reset effect state, excluding exposed parameter values.
  }

  inline void Resume()
  {
    // Note: Effect will resume and exit suspend state. Usually means the synth
    // was selected and the render callback will be called again
  }

  inline void Suspend()
  {
    // Note: Effect will enter suspend state. Usually means another effect was
    // selected and thus the render callback will not be called
  }

  /*===========================================================================*/
  /* Other Public Methods. */
  /*===========================================================================*/

  fast_inline void Process(const float *in, float *out, size_t frames)
  {
    const float *__restrict in_p = in;
    float *__restrict out_p = out;
    const float *out_e = out_p + frames; // assuming mono output

    // Caching current parameter values. Consider interpolating sensitive parameters.
    // const Params p = params_;

    const uint8_t flags = state_.flags;
    state_.flags = k_flags_none;

    const unit_runtime_osc_context_t *ctxt = static_cast<const unit_runtime_osc_context_t *>(runtime_desc_.hooks.runtime_context);
    const float w0 = state_.w0 = osc_w0f_for_note((ctxt->pitch) >> 8, ctxt->pitch & 0xFF);

    const int8_t sync_pm_phase = params_.sync_pm_phase;

    if (flags & k_flag_reset)
    {
      const uint16_t p_org = ctxt->pitch;
      uint32_t p_env = static_cast<uint32_t>(p_org) + static_cast<uint32_t>(params_.pitch_mod_depth / 100.f * 20000);
      p_env = clipmaxu32(p_env, 36864);
      p_env = p_org >= p_env ? p_org : p_env;
      state_.w0_env = osc_w0f_for_note(p_env >> 8, p_env & 0xFF);

      state_.amp = 1.f;

      // randomize
      // pm ratio
      int8_t iVal = calcRandomizedParam(params_.pm_ratio, params_.rnd_pm_ratio);
      float ratio_fIndex = iVal / 10.f;
      const int32_t ratio_index = static_cast<int32_t>(ratio_fIndex);
      if (sync_pm_phase == 1)
      {
        state_.pm_ratio = ratio_arr[ratio_index];
      }
      else
      {
        const float few = ratio_fIndex - ratio_index;
        state_.pm_ratio = ratio_index < 10 ? (ratio_arr[ratio_index] * (1 - few) + ratio_arr[ratio_index + 1] * few) : ratio_arr[10];
      }
      // pm depth
      iVal = calcRandomizedParam(params_.pm_depth, params_.rnd_pm_depth);
      state_.pm_depth = clip01f(iVal / 100.f);
      // amp decay
      iVal = calcRandomizedParam(params_.amp_decay, params_.rnd_amp_decay);
      iVal = params_.amp_decay == 100 ? iVal : clipmaxi32(iVal, 99);
      state_.amp_decay_coef = amp_decay_coef_array[iVal];
    }

    float w0_env = state_.w0_env;
    w0_env = w0_env > w0 ? w0_env : w0;
    const float w0_diff = w0_env - w0;
    const float w0_subtract = w0_diff / (k_samplerate * (params_.pitch_mod_decay + 1.f) * 0.0002f);

    float phase = (flags & k_flag_reset) ? 0.f : state_.phase;

    float pm_depth = state_.pm_depth;
    const float pm_ratio = state_.pm_ratio;
    float pm_phase = state_.pm_phase;
    pm_phase = sync_pm_phase ? pm_ratio * phase : pm_phase + pm_ratio * w0;

    float phase_moded;

    const float pm_decay_coef = 0.99f + 0.01f * powf(params_.pm_decay / 100.f, 1.f / 4.f);

    float amp = state_.amp;
    const float amp_decay_coef_processed = 0.9f + 0.1f * state_.amp_decay_coef;

    for (; out_p != out_e;)
    {
      phase_moded = phase + (pm_depth * osc_sinf(pm_phase));
      pm_depth = pm_depth < 0.0001f ? 0 : pm_depth * pm_decay_coef;

      float sig = clip1m1f(osc_sinf(phase_moded));
      sig = amp * sig;
      *(out_p++) = sig;

      amp = amp < 0.0001 ? 0 : amp * amp_decay_coef_processed;

      phase += w0_env;
      phase = (phase < 0) ? 1.f - phase : phase - (uint32_t)phase;

      pm_phase = sync_pm_phase == 2 ? pm_ratio * phase : pm_phase + pm_ratio * w0;
      pm_phase = (pm_phase < 0) ? 1.f - pm_phase : pm_phase - (uint32_t)pm_phase;

      w0_env = w0_env > w0 ? w0_env - w0_subtract : w0;
    }
    state_.pm_depth = pm_depth;
    state_.amp = amp;
    state_.w0_env = w0_env;
    state_.phase = phase;
    state_.pm_phase = pm_phase;
  }

  inline void setParameter(uint8_t index, int32_t value)
  {
    switch (index)
    {
    case M_DEPTH:
      value = clipminmaxi32(0, value, 100);
      params_.pm_depth = value;
      break;

    case RND_M_DEPTH:
      value = clipminmaxi32(0, value, 100);
      params_.rnd_pm_depth = value;
      break;

    case M_RATIO:
      value = clipminmaxi32(0, value, 100);
      params_.pm_ratio = value;
      break;

    case RND_M_RATIO:
      value = clipminmaxi32(0, value, 100);
      params_.rnd_pm_ratio = value;
      break;

    case M_DECAY:
      value = clipminmaxi32(0, value, 100);
      params_.pm_decay = value;
      break;

    case A_DECAY:
      value = clipminmaxi32(0, value, 100);
      params_.amp_decay = value;
      break;

    case RND_A_DECAY:
      value = clipminmaxi32(0, value, 100);
      params_.rnd_amp_decay = value;
      break;

    case P_DEPTH:
      value = clipminmaxi32(0, value, 100);
      params_.pitch_mod_depth = value;
      break;

    case P_DECAY:
      value = clipminmaxi32(0, value, 100);
      params_.pitch_mod_decay = value;
      break;

    case PM_SYNC:
      value = clipminmaxi32(0, value, 2);
      params_.sync_pm_phase = value;
      break;

    default:
      break;
    }
  }

  inline int32_t getParameterValue(uint8_t index) const
  {
    switch (index)
    {
    case M_DEPTH:
      return params_.pm_depth;
      break;

    case RND_M_DEPTH:
      return params_.rnd_pm_depth;
      break;

    case M_RATIO:
      return params_.pm_ratio;
      break;

    case RND_M_RATIO:
      return params_.rnd_pm_ratio;
      break;

    case M_DECAY:
      return params_.pm_decay;
      break;

    case A_DECAY:
      return params_.amp_decay;
      break;

    case RND_A_DECAY:
      return params_.rnd_amp_decay;
      break;

    case P_DEPTH:
      return params_.pitch_mod_depth;
      break;

    case P_DECAY:
      return params_.pitch_mod_decay;
      break;

    case PM_SYNC:
      return params_.sync_pm_phase;
      break;

    default:
      break;
    }

    return INT_MIN; // Note: will be handled as invalid
  }

  inline const char *getParameterStrValue(uint8_t index, int32_t value) const
  {
    // Note: String memory must be accessible even after function returned.
    //       It can be assumed that caller will have copied or used the string
    //       before the next call to getParameterStrValue

    return nullptr;
  }

  inline void setTempo(uint32_t tempo)
  {
    // const float bpmf = (tempo >> 16) + (tempo & 0xFFFF) / static_cast<float>(0x10000);
    (void)tempo;
  }

  inline void tempo4ppqnTick(uint32_t counter)
  {
    (void)counter;
  }

  inline void NoteOn(uint8_t note, uint8_t velo)
  {
    (uint8_t) note;
    (uint8_t) velo;

    // Schedule phase reset
    state_.flags |= k_flag_reset;
  }

  inline void NoteOff(uint8_t note)
  {
    (uint8_t) note;
  }

  inline void AllNoteOff()
  {
  }

  inline void PitchBend(uint8_t bend)
  {
    (uint8_t) bend;
  }

  inline void ChannelPressure(uint8_t press)
  {
    (uint8_t) press;
  }

  inline void AfterTouch(uint8_t note, uint8_t press)
  {
    (uint8_t) note;
    (uint8_t) press;
  }

  /*===========================================================================*/
  /* Static Members. */
  /*===========================================================================*/

private:
  /*===========================================================================*/
  /* Private Member Variables. */
  /*===========================================================================*/

  std::atomic_uint_fast32_t flags_;

  unit_runtime_desc_t runtime_desc_;

  Params params_;

  State state_;

  /*===========================================================================*/
  /* Private Methods. */
  /*===========================================================================*/

  inline int8_t calcRandomizedParam(int8_t param, int8_t param_rnd)
  {
    int8_t range;
    int8_t rnd;
    int8_t iVal;

    if (param_rnd <= 50)
    {
      range = 2 * param_rnd + 1;
      rnd = osc_rand() % range;
      iVal = param - param_rnd + rnd;
    }
    else
    {
      const int8_t param_rnd_sub = param_rnd - 51;
      if (param - param_rnd_sub <= 0)
      {
        range = 100 - (param + param_rnd_sub);
        rnd = osc_rand() % range;
        iVal = rnd + param + param_rnd_sub + 1;
      }
      else if (param + param_rnd_sub >= 100)
      {
        range = param - param_rnd_sub;
        rnd = osc_rand() % range;
        iVal = rnd;
      }
      else
      {
        range = 100 - 2 * param_rnd_sub;
        rnd = osc_rand() % range;
        iVal = rnd < (param - param_rnd_sub) ? rnd : rnd + (2 * param_rnd_sub) + 1;
      }
    }

    iVal = clipminmaxi32(iVal, 0, 100);

    return iVal;
  }

  /*===========================================================================*/
  /* Constants. */
  /*===========================================================================*/
};
