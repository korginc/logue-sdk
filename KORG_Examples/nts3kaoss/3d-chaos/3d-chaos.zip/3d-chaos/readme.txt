## 3D-PWC-Chaos Oscillator

This oscillator is designed to execute the exact solution of a 3-dimensional piecewise-constant chaos oscillator[1] in real time. 
It has three outputs: X, Y, and Z, and outputs from three different combinations. 
You can observe chaos attractors by putting your oscilloscope in X-Y mode.
By varying the Y-axis, you can change from periodic orbit to chaos.

### Unit Description

**Assigned Parameters**

- **X**: PITCH
- **Y**: CHAOS
- **DEPTH**: Wet Level

### Parameters Accessible from EDIT

- Combination of X, Y, Z output to L-R
- **OSC**: X-Y, X-Z, Y-Z

[1] S.Hamatani and T.Tsubone, " Analysis of a 3-dimensional piecewise-constant chaos generator
without constraint" IEICE Proceedings Series 48(A2L-B-3) (2016)


---------------------------------------------------------------------------------------------

## 3D-PWC-Chaos Oscillator

3次元区分定数カオス発振器[1]の厳密解をリアルタイム実行できるように実装したオシレータです。  
X,Y,Zの3つの出力を持ち、3つの組み合わせから出力します。  
オシロスコープでX-Yモードにすると、カオスアトラクターを観察できます。  
タッチパッドのY軸を変化させることで、周期軌道からカオスへ変化します。

### ユニットの説明

**アサインされたパラメータ**

- **X**: PITCH
- **Y**: CHAOS
- **DEPTH**: Wet Level

### EDITからアクセスするパラメータ

- L-Rから出力するX,Y,Zの組み合わせ
- **OSC**: X-Y、X-Z、Y-Z

[1] S.Hamatani and T.Tsubone, " Analysis of a 3-dimensional piecewise-constant chaos generator
without constraint" IEICE Proceedings Series 48(A2L-B-3) (2016)


