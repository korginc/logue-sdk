#pragma once
/*
    BSD 3-Clause License

    Copyright (c) 2023, KORG INC.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

//*/

/*
 *  File: effect.h
 *
 *  Dummy generic effect template instance.
 *
 */

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <climits>

#include "unit_genericfx.h"   // Note: Include base definitions for genericfx units

#include "utils/buffer_ops.h" // for buf_clr_f32()
#include "utils/int_math.h"   // for clipminmaxi32()

#include "osc_api.h"

#include "note_api.h"

#define GAIN_SCALE 0.4f
#define GAIN_UP  GAIN_SCALE / 512
#define GAIN_DOWN -GAIN_SCALE / 512
#define GAIN_SUSTAIN 0.f


class Effect {
 public:
  /*===========================================================================*/
  /* Public Data Structures/Types/Enums. */
  /*===========================================================================*/

  enum {
    BUFFER_LENGTH = 0x40000 
  };

  enum {
    PARAM1 = 0U,
    PARAM2,
    DEPTH,
    PARAM4, 
    PARAM5, 
    PARAM6, 
    NUM_PARAMS
  };

  // Note: Make sure that default param values correspond to declarations in header.c
  struct Params {
    float param1{0};
    float param2{0.f};
    float depth{0.f};
    uint32_t param4{0};
    uint32_t param5{0};
    uint32_t param6{0};

    void reset() {
      param1 = 0.f;
      param2 = 0.f;
      depth = 0.f;
      param4 = 0;
      param5 = 60;
      param6 = 72;
    }
  };

  struct State {
	float phase{0.f};
	float gain_update{0.f};
	float amp{0.f};

	void reset() {
		phase = 0.f;
		gain_update = 0.f;
		amp - 0.f;
	}
  };

  enum {
    PARAM4_VALUE0 = 0,
    PARAM4_VALUE1,
    PARAM4_VALUE2,
    PARAM4_VALUE3,
    NUM_PARAM4_VALUES,
  };

  
  /*===========================================================================*/
  /* Lifecycle Methods. */
  /*===========================================================================*/

  Effect(void) {}
  ~Effect(void) {} // Note: will never actually be called for statically allocated instances

  inline int8_t Init(const unit_runtime_desc_t * desc) {
    if (!desc)
      return k_unit_err_undef;
    
    // Note: make sure the unit is being loaded to the correct platform/module target
    if (desc->target != unit_header.common.target)
      return k_unit_err_target;
    
    // Note: check API compatibility with the one this unit was built against
    if (!UNIT_API_IS_COMPAT(desc->api))
      return k_unit_err_api_version;
    
    // Check compatibility of samplerate with unit, for NTS-3 kaoss pad kit should be 48000
    if (desc->samplerate != 48000)
      return k_unit_err_samplerate;

    // Check compatibility of frame geometry
    if (desc->input_channels != 2 || desc->output_channels != 2)  // should be stereo input/output
      return k_unit_err_geometry;

    // If SDRAM buffers are required they must be allocated here
    if (!desc->hooks.sdram_alloc)
      return k_unit_err_memory;
    float *m = (float *)desc->hooks.sdram_alloc(BUFFER_LENGTH*sizeof(float));
    if (!m)
      return k_unit_err_memory;

    // Make sure memory is cleared
    buf_clr_f32(m, BUFFER_LENGTH);
    
    allocated_buffer_ = m;

    // Cache the runtime descriptor for later use
    runtime_desc_ = *desc;

    // Make sure parameters are reset to default values
    params_.reset();
    
    return k_unit_err_none;
  }

  inline void Teardown() {
    // Note: buffers allocated via sdram_alloc are automatically freed after unit teardown
    // Note: cleanup and release resources if any
    allocated_buffer_ = nullptr;
  }

  inline void Reset() {
	state_.gain_update = GAIN_UP;
    // Note: Reset effect state, excluding exposed parameter values.
  }

  inline void Resume() {
    // Note: Effect will resume and exit suspend state. Usually means the synth
    // was selected and the render callback will be called again

    // Note: If it is required to clear large memory buffers, consider setting a flag
    //       and trigger an asynchronous progressive clear on the audio thread (Process() handler)
  }

  inline void Suspend() {
	state_.gain_update = GAIN_DOWN;
    // Note: Effect will enter suspend state. Usually means another effect was
    // selected and thus the render callback will not be called
  }

  /*===========================================================================*/
  /* Other Public Methods. */
  /*===========================================================================*/

fast_inline void Process(const float * in, float * out, size_t frames) {
    const float * __restrict in_p = in;
    float * __restrict out_p = out;
    const float * out_e = out_p + (frames << 1);  // assuming stereo output

    // Caching current parameter values. Consider interpolating sensitive parameters.

    uint8_t min_note = params_.param5;
    uint8_t max_note = params_.param6;

    ScaleType scale = (ScaleType)params_.param4;

    uint8_t midi_note = convertToMIDINote(params_.param1, min_note, max_note);
    uint8_t quantize_note = quantizeToScale(midi_note, scale, min_note);

    float freq = osc_notehzf(quantize_note);

    float phase_inc = freq / 48000.f; 

    // Temporaries
    float phase = state_.phase;
    float amp = state_.amp;
    float gain_update = state_.gain_update;

    float sample;
    float mix = 0.5 * (1.f + params_.depth);

    for (; out_p != out_e; in_p += 2, out_p += 2) {
        // Process samples here
        sample = osc_sawf(phase) * amp;
        phase += phase_inc;
        phase -= (uint32_t)phase;  // Wrap phase to range [0.0, 1.0)

        // Note: this is a dummy unit only to demonstrate APIs, only passing through audio
        out_p[0] = in_p[0] * (1.f - mix) + sample * mix;
        out_p[1] = in_p[1] * (1.f - mix) + sample * mix;

        amp += gain_update;
        if (amp >= GAIN_SCALE) {
            gain_update = GAIN_SUSTAIN;
            amp = GAIN_SCALE;
        } else if (amp < 0.f) {
            gain_update = GAIN_SUSTAIN;
            amp = 0.f;
        }
    }

    // Update state
    state_.phase = phase;
    state_.amp = amp;
    state_.gain_update = gain_update;
}

  inline void setParameter(uint8_t index, int32_t value) {
    switch (index) {
    case PARAM1:
      // 10bit 0-1023 parameter
      value = clipminmaxi32(0, value, 1023);
    //   params_.param1 = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
	  params_.param1 = (float)value;
      break;

    case PARAM2:
      // 10bit 0-1023 parameter
      value = clipminmaxi32(0, value, 1023);
      params_.param2 = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
      break;

    case DEPTH:
      // Single digit base-10 fractional value, bipolar dry/wet
      value = clipminmaxi32(-1000, value, 1000);
      params_.depth = value / 1000.f; // -100.0 .. 100.0 -> -1.0 .. 1.0
      break;

    case PARAM4:
      // strings type parameter, receiving index value
      value = clipminmaxi32(CHROMATIC, value, SCALE_MAX-1);
      params_.param4 = value;
      break;
	case PARAM5:
      value = clipminmaxi32(NOTE_MIN, value, NOTE_MAX);
      params_.param5 = value;
      break;
	case PARAM6:
      value = clipminmaxi32(NOTE_MIN, value, NOTE_MAX);
      params_.param6 = value;
      break;
	  
      
    default:
      break;
    }
  }

  inline int32_t getParameterValue(uint8_t index) const {
    switch (index) {
    case PARAM1:
      // 10bit 0-1023 parameter
    //   return param_f32_to_10bit(params_.param1);
	  return params_.param1;
      break;

    case PARAM2:
      // 10bit 0-1023 parameter
      return param_f32_to_10bit(params_.param2);
      break;

    case DEPTH:
      // Single digit base-10 fractional value, bipolar dry/wet
      return (int32_t)(params_.depth * 1000);
      break;

    case PARAM4:
      // strings type parameter, return index value
      return params_.param4;

	case PARAM5:
      // strings type parameter, return index value
      return params_.param5;

	case PARAM6:
      // strings type parameter, return index value
      return params_.param6;
      
    default:
      break;
    }

    return INT_MIN; // Note: will be handled as invalid
  }

  inline const char * getParameterStrValue(uint8_t index, int32_t value) const {
    // Note: String memory must be accessible even after function returned.
    //       It can be assumed that caller will have copied or used the string
    //       before the next call to getParameterStrValue


    switch (index) {
    case PARAM4:
    //   if (value >= CHROMATIC && value < SCALE_MAX)
      if (value >= 0 && value < 6)
        return scaleNames[value];
      break;
	case PARAM5:
	case PARAM6:
    //   if (value >= NOTE_MIN && value < NOTE_MAX)
      if (value >= 0 && value < 128)
        return noteNames[value];
		break;
    default:
      break;
    }
    
    return nullptr;
  }
  
  inline void setTempo(uint32_t tempo) {
    // const float bpmf = (tempo >> 16) + (tempo & 0xFFFF) / static_cast<float>(0x10000);
    (void)tempo;
  }

  inline void tempo4ppqnTick(uint32_t counter) {
    (void)counter;
  }

  inline void touchEvent(uint8_t id, uint8_t phase, uint32_t x, uint32_t y) {
    // Note: Touch x/y events are already mapped to specific parameters so there is usually there no need to set parameters from here.
    //       Audio source type effects, for instance, may require these events to trigger enveloppes and such.
    
    (void)id;
    (void)phase;
    (void)x;
    (void)y;
    
    switch (phase) {
    case k_unit_touch_phase_began:
	  Effect::Reset();
      break;
    case k_unit_touch_phase_moved:
      break;
    case k_unit_touch_phase_ended:
	  Effect::Suspend();
      break;  
    case k_unit_touch_phase_stationary:
      break;
    case k_unit_touch_phase_cancelled:
      break; 
    default:
      break;
    }
  }
  
  /*===========================================================================*/
  /* Static Members. */
  /*===========================================================================*/
  
 private:
  /*===========================================================================*/
  /* Private Member Variables. */
  /*===========================================================================*/

  std::atomic_uint_fast32_t flags_;

  unit_runtime_desc_t runtime_desc_;

  Params params_;
  State state_;
  
  float * allocated_buffer_;
  
  /*===========================================================================*/
  /* Private Methods. */
  /*===========================================================================*/

  /*===========================================================================*/
  /* Constants. */
  /*===========================================================================*/
};
