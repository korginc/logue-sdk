#ifndef NOTE_API_H
#define NOTE_API_H

#include <stdlib.h>


#define	NOTE_MIN   0
#define NOTE_MAX 128

static const char *noteNames[NOTE_MAX] = {
    "C-1", "C'-1", "D-1", "D'-1", "E-1", "F-1", "F'-1", "G-1", "G'-1", "A-1", "A'-1", "B-1",
    "C0", "C'0", "D0", "D'0", "E0", "F0", "F'0", "G0", "G'0", "A0", "A'0", "B0",
    "C1", "C'1", "D1", "D'1", "E1", "F1", "F'1", "G1", "G'1", "A1", "A'1", "B1",
    "C2", "C'2", "D2", "D'2", "E2", "F2", "F'2", "G2", "G'2", "A2", "A'2", "B2",
    "C3", "C'3", "D3", "D'3", "E3", "F3", "F'3", "G3", "G'3", "A3", "A'3", "B3",
    "C4", "C'4", "D4", "D'4", "E4", "F4", "F'4", "G4", "G'4", "A4", "A'4", "B4",
    "C5", "C'5", "D5", "D'5", "E5", "F5", "F'5", "G5", "G'5", "A5", "A'5", "B5",
    "C6", "C'6", "D6", "D'6", "E6", "F6", "F'6", "G6", "G'6", "A6", "A'6", "B6",
    "C7", "C'7", "D7", "D'7", "E7", "F7", "F'7", "G7", "G'7", "A7", "A'7", "B7",
    "C8", "C'8", "D8", "D'8", "E8", "F8", "F'8", "G8", "G'8", "A8", "A'8", "B8",
    "C9", "C'9", "D9", "D'9", "E9", "F9", "F'9", "G9"
};


typedef enum {
    CHROMATIC,
    LYDIAN,
    DORIAN,
    IONIAN,
    MAJOR_PENTATONIC,
    MINOR_PENTATONIC,
    SCALE_MAX
} ScaleType;

static const char *scaleNames[SCALE_MAX] = {
    "CHROMA",
    "LYDIAN",
    "DORIAN",
    "IONIAN",
    "MJ PEN",
    "MI PEN"
};

static uint8_t chromaticScale[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11};
static uint8_t lydianScale[] = {0, 2, 4, 6, 7, 9, 11};
static uint8_t dorianScale[] = {0, 2, 3, 5, 7, 9, 10};
static uint8_t ionianScale[] = {0, 2, 4, 5, 7, 9, 11};
static uint8_t majorPentatonicScale[] = {0, 2, 4, 7, 9};
static uint8_t minorPentatonicScale[] = {0, 3, 5, 7, 10};

static void getScaleOffsets(ScaleType scale, uint8_t **scaleOffsets, uint8_t *scaleSize) {
    switch (scale) {
        case CHROMATIC:
            *scaleOffsets = chromaticScale;
            *scaleSize = sizeof(chromaticScale) / sizeof(uint8_t);
            break;
        case LYDIAN:
            *scaleOffsets = lydianScale;
            *scaleSize = sizeof(lydianScale) / sizeof(uint8_t);
            break;
        case DORIAN:
            *scaleOffsets = dorianScale;
            *scaleSize = sizeof(dorianScale) / sizeof(uint8_t);
            break;
        case IONIAN:
            *scaleOffsets = ionianScale;
            *scaleSize = sizeof(ionianScale) / sizeof(uint8_t);
            break;
        case MAJOR_PENTATONIC:
            *scaleOffsets = majorPentatonicScale;
            *scaleSize = sizeof(majorPentatonicScale) / sizeof(uint8_t);
            break;
        case MINOR_PENTATONIC:
            *scaleOffsets = minorPentatonicScale;
            *scaleSize = sizeof(minorPentatonicScale) / sizeof(uint8_t);
            break;
        default:
            *scaleOffsets = chromaticScale;
            *scaleSize = sizeof(chromaticScale) / sizeof(uint8_t);
            break;
    }
}

static uint8_t getKeyFromMinNote(uint8_t minNote) {
    return minNote % 12;
}

static uint8_t quantizeToScale(uint8_t midiNote, ScaleType scaleType, uint8_t key) {
    uint8_t *scaleOffsets;
    uint8_t scaleSize;
    getScaleOffsets(scaleType, &scaleOffsets, &scaleSize);

    uint8_t octave = midiNote / 12;
    uint8_t noteInOctave = midiNote % 12;

    // �ł��߂��X�P�[���m�[�g��T��
    uint8_t closestNote = (scaleOffsets[0] + key) % 12;
    uint8_t minDistance = abs(noteInOctave - closestNote);
    for (uint8_t i = 1; i < scaleSize; i++) {
        uint8_t currentNote = (scaleOffsets[i] + key) % 12;
        uint8_t distance = abs(noteInOctave - currentNote);
        if (distance < minDistance) {
            minDistance = distance;
            closestNote = currentNote;
        }
    }

    return (uint8_t)(octave * 12 + closestNote);
}

static uint8_t convertToMIDINote(float value, uint8_t minNote, uint8_t maxNote) {
    if (value > 1023.0f) value = 1023.0f;

    int8_t noteRange = maxNote - minNote;
    float valueRange = 1023.0f;
    float noteWidth = valueRange / abs(noteRange);

    uint8_t midiNote;
    if (noteRange >= 0) {
        midiNote = minNote + (uint8_t)((value / noteWidth) + 0.5);
    } else {
        midiNote = minNote - (uint8_t)((value / noteWidth) + 0.5);
    }

    if (noteRange >= 0) {
        if (midiNote < minNote) midiNote = minNote;
        if (midiNote > maxNote) midiNote = maxNote;
    } else {
        if (midiNote > minNote) midiNote = minNote;
        if (midiNote < maxNote) midiNote = maxNote;
    }

    return midiNote;
}

#endif // NOTE_API_H