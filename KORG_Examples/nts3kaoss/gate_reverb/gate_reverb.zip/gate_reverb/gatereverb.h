#pragma once
/*
    BSD 3-Clause License

    Copyright (c) 2023, KORG INC.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

//*/

/*
 *  File: gatereverb.h
 *
 *  Example of using SDRAM for delay lines
 *
 */

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <climits>

#include "unit_genericfx.h"   // Note: Include base definitions for genericfx units

#include "utils/buffer_ops.h"
#include "utils/int_math.h"

#include "dsp/biquad.hpp"

class Effect {
public:
  /*===========================================================================*/
  /* Public Data Structures/Types/Enums. */
  /*===========================================================================*/

  enum {
    PREDELAY_BUF_SIZE = 0x20000,
    COMB_SIZE = 0x8000,
    APF_BUF_SIZE = 0x4000U,
    REVERB_DSP_BUF_SIZE = PREDELAY_BUF_SIZE + COMB_SIZE + APF_BUF_SIZE
  };

  enum {
    GATE = 0U,
    TIME,
    DEPTH,
    TONE,
    DRYWET, 
    NUM_PARAMS
  };

  // Note: Make sure that default param values correspond to declarations in header.c
  struct Params {
    float gate{0.f};
    float time{0.f};
    float depth{0.f};
    float tone{0.f};
    float drywet{0.f};
   

    void reset() {
      gate = 0.f;
      time = 0.f;
      depth = 0.f;
      tone = 0.f;
      drywet = 0.f;
    }
  }; 

  
  /*===========================================================================*/
  /* Lifecycle Methods. */
  /*===========================================================================*/

  Effect(void) {}
  ~Effect(void) {} // Note: will never actually be called for statically allocated instances

  inline int8_t Init(const unit_runtime_desc_t * desc) {
    if (!desc)
      return k_unit_err_undef;
    
    // Note: make sure the unit is being loaded to the correct platform/module target
    if (desc->target != unit_header.common.target)
      return k_unit_err_target;
    
    // Note: check API compatibility with the one this unit was built against
    if (!UNIT_API_IS_COMPAT(desc->api))
      return k_unit_err_api_version;
    
    // Check compatibility of samplerate with unit, for NTS-3 kaoss pad kit should be 48000
    if (desc->samplerate != 48000)
      return k_unit_err_samplerate;

    // Check compatibility of frame geometry
    if (desc->input_channels != 2 || desc->output_channels != 2)  // should be stereo input/output
      return k_unit_err_geometry;


    // If SDRAM buffers are required they must be allocated here
    if (!desc->hooks.sdram_alloc)
      return k_unit_err_memory;
    float *m = (float *)desc->hooks.sdram_alloc(REVERB_DSP_BUF_SIZE*sizeof(float));    
    if (!m)
      return k_unit_err_memory;

    buf_clr_f32(m, REVERB_DSP_BUF_SIZE);

    reverb_dsp_buf_ = m;
    predelay_buf_ = m;
    m += PREDELAY_BUF_SIZE;
    comb_buf_ = m;
    m += COMB_SIZE;
    allpassfilter_buf_ = m;

    
    // Cache the runtime descriptor for later use
    runtime_desc_ = *desc;

    // Make sure parameters are reset to default values
    params_.reset();
    
    return k_unit_err_none;
  }

  inline void Teardown() {
    // Note: buffers allocated via sdram_alloc are automatically freed after unit teardown
    // Note: cleanup and release resources if any
    reverb_dsp_buf_ = nullptr;
    predelay_buf_ = nullptr;
    comb_buf_ = nullptr;
    allpassfilter_buf_ = nullptr;
  }

  inline void Reset() {
    // Note: Reset effect state, excluding exposed parameter values.
  }

  inline void Resume() {
    // Note: Effect will resume and exit suspend state. Usually means the synth
    // was selected and the render callback will be called again

    // Note: If it is required to clear large memory buffers, consider setting a flag
    //       and trigger an asynchronous progressive clear on the audio thread (Process() handler)
    s_clear_lines = true;
  }

  inline void Suspend() {
    // Note: Effect will enter suspend state. Usually means another effect was
    // selected and thus the render callback will not be called
  }

  /*===========================================================================*/
  /* Other Public Methods. */
  /*===========================================================================*/

  fast_inline void Process(const float * in, float * out, size_t frames) {
    const float * __restrict in_p = in;
    float * __restrict out_p = out;
    const float * out_e = out_p + (frames << 1);  // assuming stereo output


    // Clearing SDRAM
    if (s_clear_lines) {
      uint32_t cleared = s_cleared_frames;
      uint32_t to_clear = 0;
      float * line = nullptr;
      if (cleared < REVERB_DSP_BUF_SIZE) {
	to_clear = (frames<<6 < (REVERB_DSP_BUF_SIZE - cleared))
	  ? (frames<<6) : (REVERB_DSP_BUF_SIZE - cleared);
	if (reverb_dsp_buf_) {
	  line = reverb_dsp_buf_ + cleared;
	}
      }
      if (line) {
	buf_clr_f32(line, to_clear);
	s_cleared_frames += to_clear;	
	buf_cpy_f32(in, out, frames<<1); 
	return; // Passthrough until cleared
      }      
      s_clear_lines = false; // Done clearing
    }


    // Caching current parameter values. Consider interpolating sensitive parameters.    
    const Params p = params_;

    float wetmix = p.drywet;
    float drymix = 1.0f - p.drywet;
    float drymixz = s_drymixz;
    float wetmixz = s_wetmixz;    
    const float drymix_d = (drymix - drymixz) * interp_ratio_48KHz;
    const float wetmix_d = (wetmix - wetmixz) * interp_ratio_48KHz;        
          
    const float predelay = 0.5f;     //May be made controllable
    timeratio = p.time;

    uint32_t writeidx = s_writeidx;

    const float gate = p.gate;
    float gatez = s_gatez;
    float rmsz = s_rmsz;


    updateHighDamp(p.tone);    
    
    for (; out_p != out_e; in_p += 2, out_p += 2) {

      const float reverbIn = in_p[0] + in_p[1];
      // 1. predelay
      {
	const float predelayIn = reverbIn * 0.4f;
	predelay_buf_[writeidx & (PREDELAY_BUF_SIZE-1)] = predelayIn;
      }

      // 2. allpass filter
      float combin, wet_l, wet_r;
      {
	const float preDelaySig = predelay_buf_[(writeidx + ((uint16_t)predelay)) & (PREDELAY_BUF_SIZE-1)];
	float apf1Sig1 = reverbIn * 0.5f + preDelaySig;
	float apf1Sig2 = apf1234In[1];
	float apf1Sig3 = apf1234In[2];
	float apf1Sig4 = apf1234In[3];

	const float apf2Sig1 = allpassfilter_buf_[((s_apf1234_time[0] + writeidx) & (APF_BUF_SIZE-1)) * 4 + 0];
	const float apf2Sig2 = allpassfilter_buf_[((s_apf1234_time[1] + writeidx) & (APF_BUF_SIZE-1)) * 4 + 1];
	const float apf2Sig3 = allpassfilter_buf_[((s_apf1234_time[2] + writeidx) & (APF_BUF_SIZE-1)) * 4 + 2];
	const float apf2Sig4 = allpassfilter_buf_[((s_apf1234_time[3] + writeidx) & (APF_BUF_SIZE-1)) * 4 + 3];

	{
	  const float c0 = apf2Sig1 * -0.5f;
	  const float c1 = apf2Sig2 * -0.5f;
	  const float c2 = apf2Sig3 * -0.5f;
	  const float c3 = apf2Sig4 * -0.5f;
        
	  apf1Sig1 += c0;
	  apf1Sig2 += c1;
	  apf1Sig3 += c2;
	  apf1Sig4 += c3;
	}

	const uint32_t apfwriteidx = (writeidx & (APF_BUF_SIZE-1)) * 4;
	allpassfilter_buf_[apfwriteidx + 0] = apf1Sig1;
	allpassfilter_buf_[apfwriteidx + 1] = apf1Sig2;
	allpassfilter_buf_[apfwriteidx + 2] = apf1Sig3;
	allpassfilter_buf_[apfwriteidx + 3] = apf1Sig4;

	{
	  const float c0 = apf1Sig1 * -0.5f;
	  const float c1 = apf1Sig2 * -0.5f;
	  const float c2 = apf1Sig3 * -0.5f;
	  const float c3 = apf1Sig4 * -0.5f;
        
	  apf1234In[1] = apf2Sig1 - c0;  // apf out 0
	  combin = apf2Sig2 - c1;        // apf out 1
	  wet_l = apf2Sig3 - c2;         // apf out 2
	  wet_r = apf2Sig4 - c3;         // apf out 3
	}
      }

      // 4. comb filter
      {
	const float apfInt = combin * 0.666f;
      
	const float comb1 = comb_buf_[((writeidx + s_comb_fbtime[0]) & (COMB_SIZE-1)) * 4 + 0];
	const float comb2 = comb_buf_[((writeidx + s_comb_fbtime[1]) & (COMB_SIZE-1)) * 4 + 1];
	const float comb3 = comb_buf_[((writeidx + s_comb_fbtime[2]) & (COMB_SIZE-1)) * 4 + 2];
	const float comb4 = comb_buf_[((writeidx + s_comb_fbtime[3]) & (COMB_SIZE-1)) * 4 + 3];
      
	float combSig1 = (apfInt + (comb1 * timeratio));
	float combSig2 = (apfInt + (comb2 * (-1.f * timeratio)));
	float combSig3 = (apfInt + (comb3 * (timeratio)));
	float combSig4 = (apfInt + (comb4 * (-1.f * timeratio)));
      
	combSig1 = (((combhidampz[0] + combSig1) * combhidamp[0]) - combSig1);
	combSig2 = (((combhidampz[1] + combSig2) * combhidamp[1]) - combSig2);
	combSig3 = (((combhidampz[2] + combSig3) * combhidamp[2]) - combSig3);
	combSig4 = (((combhidampz[3] + combSig4) * combhidamp[3]) - combSig4);

	combhidampz[0] = combSig1;
	combhidampz[1] = combSig2;
	combhidampz[2] = combSig3;
	combhidampz[3] = combSig4;
      
	const uint32_t combwriteidx = (writeidx & (COMB_SIZE-1)) * 4;
	comb_buf_[combwriteidx + 0] = (combSig1);
	comb_buf_[combwriteidx + 1] = (combSig2);
	comb_buf_[combwriteidx + 2] = (combSig3);
	comb_buf_[combwriteidx + 3] = (combSig4);
      }

      // Read Comb Taps      
      {	
	float sig_l = comb_buf_[((writeidx + s_comb_tapltime[0]) & (COMB_SIZE-1)) * 4 + 0];
	float sig_r = comb_buf_[((writeidx + s_comb_taprtime[0]) & (COMB_SIZE-1)) * 4 + 0];

	sig_l += comb_buf_[((writeidx + s_comb_tapltime[1]) & (COMB_SIZE-1)) * 4 + 1];
	sig_r += comb_buf_[((writeidx + s_comb_taprtime[1]) & (COMB_SIZE-1)) * 4 + 1];

	sig_l += comb_buf_[((writeidx + s_comb_tapltime[2]) & (COMB_SIZE-1)) * 4 + 2];
	sig_r += comb_buf_[((writeidx + s_comb_taprtime[2]) & (COMB_SIZE-1)) * 4 + 2];

	sig_l += comb_buf_[((writeidx + s_comb_tapltime[3]) & (COMB_SIZE-1)) * 4 + 3];
	sig_r += comb_buf_[((writeidx + s_comb_taprtime[3]) & (COMB_SIZE-1)) * 4 + 3];
      
	apf1234In[2] = sig_l * 0.5f;
	apf1234In[3] = sig_r * 0.5f;
      }

      // Gate
      {	
	const float gateIn = wet_l + wet_r;
	float rms = gateIn * gateIn;
	rms = (rms > 1.f) ? 1.f : (rms < 0.f) ? 0.f : rms;
	rms = (rms < (PeakHoldCoeff * s_peak_holdz)) ? (PeakHoldCoeff * s_peak_holdz) : rms;
	s_peak_holdz = rms;
	float rms_db = fasterampdbf(rms * 0.5f);
	if(rms_db < fasterampdbf(gate*gate*0.2f)){
	  gatez = linintf(gate_attack_time, gatez, 0.f);
	}
	else {
	  gatez = linintf(gate_release_time, gatez, 1.f);
	}
	wet_l = wet_l * gatez;
	wet_r = wet_r * gatez;
      }

      // 7. output      
      drymixz += drymix_d;
      wetmixz += wetmix_d;
      out_p[0] = drymixz * (in_p[0]) + wetmixz * wet_l;
      out_p[1] = drymixz * (in_p[1]) + wetmixz * wet_r;

      --writeidx;
    }

    s_writeidx = writeidx;
    s_drymixz = drymixz;
    s_wetmixz = wetmixz;
    s_gatez = gatez;
    s_rmsz = rmsz;
  }

  inline void setParameter(uint8_t index, int32_t value) {
    switch (index) {
    case GATE: // 10bit 0-1023 parameter      
      value = clipminmaxi32(0, value, 1023);
      params_.gate = param_10bit_to_f32(value); // 0 .. 1023 -> 0.0 .. 1.0
      break;
    case TIME:
      value = clipminmaxi32(0, value, 1023);
      params_.time = param_10bit_to_f32(value);
      break;
    case DEPTH:
      value = clipminmaxi32(0, value, 1023);
      params_.depth = param_10bit_to_f32(value);
      break;
    case TONE:
      value = clipminmaxi32(0, value, 1023);
      params_.tone = param_10bit_to_f32(value);
      break;
    case DRYWET:
      value = clipminmaxi32(0, value, 1023);
      params_.drywet = param_10bit_to_f32(value);
      break;      
    default:
      break;
    }
  }

  inline int32_t getParameterValue(uint8_t index) const {
    switch (index) {
    case GATE:
      return param_f32_to_10bit(params_.gate);
      break;
    case TIME:
      return param_f32_to_10bit(params_.time);
      break;
    case DEPTH:
      return param_f32_to_10bit(params_.depth);
      break;
    case TONE:
      return param_f32_to_10bit(params_.tone);
      break;
    case DRYWET:
      return param_f32_to_10bit(params_.drywet);
      break;      
    default:
      break;
    }

    return INT_MIN; // Note: will be handled as invalid
  }

  inline const char * getParameterStrValue(uint8_t index, int32_t value) const {
    // Note: String memory must be accessible even after function returned.
    //       It can be assumed that caller will have copied or used the string
    //       before the next call to getParameterStrValue    
    return nullptr;
  }
  
  inline void setTempo(uint32_t tempo) {
    // const float bpmf = (tempo >> 16) + (tempo & 0xFFFF) / static_cast<float>(0x10000);
    (void)tempo;
  }

  inline void tempo4ppqnTick(uint32_t counter) {
    (void)counter;
  }

  inline void touchEvent(uint8_t id, uint8_t phase, uint32_t x, uint32_t y) {    
    (void)id;
    (void)phase;
    (void)x;
    (void)y;
  }
  
  /*===========================================================================*/
  /* Static Members. */
  /*===========================================================================*/
  
private:
  /*===========================================================================*/
  /* Private Member Variables. */
  /*===========================================================================*/

  std::atomic_uint_fast32_t flags_;
  unit_runtime_desc_t runtime_desc_;
  Params params_;

  uint32_t s_cleared_frames;
  bool     s_clear_lines;
  
  float *reverb_dsp_buf_;
  float *predelay_buf_;  
  float *comb_buf_;
  float *allpassfilter_buf_;

  uint32_t s_writeidx = 0;
  float    s_drymixz = 1.f;
  float    s_wetmixz = 1.f;  
  float    timeratio = 0.f;

  float s_peak_holdz = 0.f;
  float s_gatez = 1.f;
  float s_rmsz = 1.f;

  float apf1234In[4] __attribute__((aligned(4)));
  float combhidamp[4] __attribute__((aligned(4)));
  float combhidampz[4] __attribute__((aligned(4))); 

  
  /*===========================================================================*/
  /* Private Methods. */
  /*===========================================================================*/

  void updateHighDamp(float damp){
    damp = (damp * 0.5f) + 0.5f;
    const float comb1 = damp * 1.0f;
    const float comb2 = damp * 0.9f;
    const float comb3 = damp * 0.85f;
    const float comb4 = damp * 0.77f;
    combhidamp[0] = (comb1);
    combhidamp[1] = (comb2);
    combhidamp[2] = (comb3);
    combhidamp[3] = (comb4);    
  }

  /*===========================================================================*/
  /* Constants. */
  /*===========================================================================*/

  const float interp_ratio_48KHz = 0.002083333333333f; // ~480 samples @ 48KHz -> ~10ms 

  const float PeakHoldCoeff = 0.999725f;
  const float gate_attack_time = 0.075f;
  const float gate_release_time = 0.00003f;

  const uint32_t s_apf1234_time[4] __attribute__((aligned(4))) = {
    0x0570,
    0x0a30,
    0x0740,
    0x0470
  };

  const uint32_t s_comb_fbtime[4] __attribute__((aligned(4))) = {
    0x1ba0,
    0x19e0,
    0x1740,
    0x1590
  };

  const uint32_t s_comb_tapltime[4] __attribute__((aligned(4))) = {
    0x0ae0,
    0x0a50,
    0x0780,
    0x04b0
  };

  const uint32_t s_comb_taprtime[4] __attribute__((aligned(4))) = {
    0x0e10,
    0x0690,
    0x05a0,
    0x02e0
  };
};
