# nts3-osc-harmonics

This oscillator is inspired by the harmonic generators used in West Coast Synthesis.

The design is based around an addivite engine that consists of 8 harmonically-related sinewave oscillators running in parallel and summed at the output. To play the oscillator, the user sweeps through the harmonics using the X-AXIS on the kaoss pad. The so-called "width" of the frequency sweep is controlled via the Y-AXIS. At the minimum width only individual harmonics will be heard, while maximum width allows all harmonics to be heard. The fundamental frequency, or pitch, of the oscillator is controlled via the DEPTH control. 

This oscillator operates under a different musical paradigm in the sense that it is not "played" like a normal oscillator. Rather than controlling pitch to build melodies, the user manipulates frequency content to create interesting harmonic patterns. Expressivity and articulation are achieved via the width of the harmonic sweep or scan.

3 modes of operation are available:

    - GATE: Oscillator responds to note ON, note OFF and SUSTAIN events via the kaosspad.
    – FREE: Oscillator is always playing. 
    – AUTO: X-AXIS is disabled and scan is controled by an internal random LFO. Rate of the oscillator is controlled via the LFO RATE parameter.

TIP: Apply delay and reveb effects for rich harmonic textures.