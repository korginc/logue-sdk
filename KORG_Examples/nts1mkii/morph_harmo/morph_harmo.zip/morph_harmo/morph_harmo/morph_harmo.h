#pragma once
/*
    BSD 3-Clause License

    Copyright (c) 2023, KORG INC.
    All rights reserved.

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this
      list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright notice,
      this list of conditions and the following disclaimer in the documentation
      and/or other materials provided with the distribution.

    * Neither the name of the copyright holder nor the names of its
      contributors may be used to endorse or promote products derived from
      this software without specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
    AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
    IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
    DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
    DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
    SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
    OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

//*/

/*
 *  File: osc.h
 *
 *  Dummy oscillator template instance.
 *
 */

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <climits>
#include <vector>

#include "unit_osc.h" // Note: Include base definitions for osc units

#include "utils/int_math.h" // for clipminmaxi32()

#define MAKE_INTEGRAL_FRACTIONAL(x)               \
  int32_t x##_integral = static_cast<int32_t>(x); \
  float x##_fractional = x - static_cast<float>(x##_integral);

class Morph_harmo
{
public:
  /*===========================================================================*/
  /* Public Data Structures/Types/Enums. */
  /*===========================================================================*/

  enum
  {
    WAVE = 0U,
    DICE,
    OSC1,
    OSC2,
    OSC3,
    OSC4,
    OSC5,
    OSC6,
    QUANTIZE_DEPTH,
    TRANS_TIME,
    NUM_PARAMS
  };

  float w_table[k_midi_to_hz_size];
  int16_t w_table_size;

  bool maj_scale_notes[12]{true, false, true, false, true, true, false, true, false, true, false, true};

  const float *wavetable;
  const int8_t maxWaveIndex{k_waves_a_cnt - 1};

  // Note: Make sure that default param values correspond to declarations in header.c
  struct Params
  {
    int32_t wave{0};
    int8_t dice{0};
    int16_t freq_param_arr[6]{100, 100, 100, 100, 100, 100};
    int8_t quant_depth{100};
    int8_t quant_time{15};

    void reset()
    {
      wave = 0;
      dice = 0;
      for (int i = 0; i < 6; i++)
      {
        freq_param_arr[i] = 100;
      }
      quant_depth = 100;
      quant_time = 15;
    }
  };

  enum
  {
    k_flags_none = 0,
    k_flag_reset = 1 << 0,
  };

  struct State
  {
    float wave{0.f};
    float phase_arr[6]{0, 0, 0, 0, 0, 0};
    float w0{440.f * k_samplerate_recipf}; // phase increment
    float freq_coef_arr[6]{1.f, 1.f, 1.f, 1.f, 1.f, 1.f};
    float w_now_arr[6]{w0, w0, w0, w0, w0, w0};

    float lfoz{0.f};

    std::atomic_uint_fast32_t flags{k_flags_none};

    inline void Reset(void)
    {
      w0 = 440.f * k_samplerate_recipf;
      wave = 0.f;
      for (int i = 0; i < 6; i++)
      {
        phase_arr[i] = 0;
        freq_coef_arr[i] = 1.f;
        w_now_arr[i] = w0;
      }

      lfoz = 0.f;

      flags = k_flags_none;
    }
  };

  /*===========================================================================*/
  /* Lifecycle Methods. */
  /*===========================================================================*/

  Morph_harmo(void) {}
  ~Morph_harmo(void) {} // Note: will never actually be called for statically allocated instances

  inline int8_t Init(const unit_runtime_desc_t *desc)
  {
    if (!desc)
      return k_unit_err_undef;

    // Note: make sure the unit is being loaded to the correct platform/module target
    if (desc->target != unit_header.target)
      return k_unit_err_target;

    // Note: check API compatibility with the one this unit was built against
    if (!UNIT_API_IS_COMPAT(desc->api))
      return k_unit_err_api_version;

    // Check compatibility of samplerate with unit, for NTS-1 MKII should be 48000
    if (desc->samplerate != 48000)
      return k_unit_err_samplerate;

    // Check compatibility of frame geometry
    // Note: NTS-1 mkII oscillators can make use of the audio input depending on the routing options in global settings, see product documentation for details.
    if (desc->input_channels != 2 || desc->output_channels != 1) // should be stereo input / mono output
      return k_unit_err_geometry;

    // Note: SDRAM is not available from the oscillator runtime environment

    // Cache the runtime descriptor for later use
    runtime_desc_ = *desc;

    // Make sure parameters are reset to default values

    params_.reset();

    w_table_size = 0;
    for (int i = 0; i < k_midi_to_hz_size; i = i + 12)
    {
      for (int n = 0; n < 12; n++)
      {
        bool isEnable = maj_scale_notes[n];
        if (isEnable)
        {
          int16_t noteNumber = n + i;
          if (noteNumber < k_midi_to_hz_size)
          {
            w_table[w_table_size] = osc_w0f_for_note(noteNumber, 0);
            w_table_size = w_table_size + 1;
          }
        }
      }
    }

    return k_unit_err_none;
  }

  inline void Teardown()
  {
    // Note: cleanup and release resources if any
  }

  inline void Reset()
  {
    // Note: Reset effect state, excluding exposed parameter values.
  }

  inline void Resume()
  {
    // Note: Effect will resume and exit suspend state. Usually means the synth
    // was selected and the render callback will be called again
  }

  inline void Suspend()
  {
    // Note: Effect will enter suspend state. Usually means another effect was
    // selected and thus the render callback will not be called
  }

  /*===========================================================================*/
  /* Other Public Methods. */
  /*===========================================================================*/

  fast_inline void Process(const float *in, float *out, size_t frames)
  {
    const float *__restrict in_p = in;
    float *__restrict out_p = out;
    const float *out_e = out_p + frames; // assuming mono output

    // Caching current parameter values. Consider interpolating sensitive parameters.
    // const Params p = params_;

    const uint8_t flags = state_.flags;
    state_.flags = k_flags_none;

    const unit_runtime_osc_context_t *ctxt = static_cast<const unit_runtime_osc_context_t *>(runtime_desc_.hooks.runtime_context);
    const float w0 = state_.w0 = osc_w0f_for_note((ctxt->pitch) >> 8, ctxt->pitch & 0xFF);

    // float coef_arr[6]{1, 1, 1, 1, 1, 1};
    float phase_arr[6]{0, 0, 0, 0, 0, 0};
    float w_now_arr[6]{0, 0, 0, 0, 0, 0};
    float w_incr_arr[6]{0, 0, 0, 0, 0, 0};

    const float quant_depth = params_.quant_depth / 100.f;
    const float quant_time = 4.f * (params_.quant_time / 100.f) * (params_.quant_time / 100.f);

    for (int i = 0; i < 6; i++)
    {
      phase_arr[i] = state_.phase_arr[i];
      float w_not_quant = w0 * state_.freq_coef_arr[i];
      // w_now_arr[i] = flags & k_flag_reset ? w_not_quant : state_.w_now_arr[i];
      w_now_arr[i] = state_.w_now_arr[i];

      int idx = w_table_size;
      for (int i = 0; i < w_table_size; i++)
      {
        if (w_table[i] > w_not_quant)
        {
          idx = i;
          break;
        }
      }
      float w_quant;
      if (idx == 0)
      {
        w_quant = w_table[0];
      }
      else if (idx > w_table_size - 1)
      {
        w_quant = w_table[w_table_size - 1];
      }
      else
      {
        float higher = w_table[idx];
        float lower = w_table[idx - 1];
        float delta_higher = higher - w_not_quant;
        float delta_lower = w_not_quant - lower;
        w_quant = delta_higher < delta_lower ? higher : lower;
      }
      float w_target = w_not_quant + quant_depth * (w_quant - (w0 * state_.freq_coef_arr[i]));
      w_incr_arr[i] = (w_target - w_now_arr[i]) / (static_cast<int16_t>(frames) + (quant_time * k_samplerate));
    }

    const float lfo = q31_to_f32(ctxt->shape_lfo);
    float lfoz = state_.lfoz;
    const float lfo_inc = (lfo - lfoz) / frames;

    float p;
    float sig;

    float wave = 0.f;

    for (; out_p != out_e;)
    {
      // Process/generate samples here
      sig = 0;
      for (int i = 0; i < 6; i++)
      {
        p = phase_arr[i];
        p = (p <= 0) ? 1.f - p : p - (uint32_t)p;

        wave = clipminmaxf(0.f, (state_.wave + lfoz) * maxWaveIndex, static_cast<float>(maxWaveIndex));
        MAKE_INTEGRAL_FRACTIONAL(wave);

        sig += (1 - wave_fractional) * osc_wave_scanf(wavesA[wave_integral], p);
        const int8_t nextIndex = wave_integral < maxWaveIndex ? wave_integral + 1 : wave_integral;
        sig += wave_fractional * osc_wave_scanf(wavesA[wave_integral + 1], p);

        phase_arr[i] += w_now_arr[i];
        phase_arr[i] -= (uint32_t)phase_arr[i];
        w_now_arr[i] += w_incr_arr[i];
      }
      sig /= 6.f;
      sig = clip1m1f(sig);
      *(out_p++) = sig;
      lfoz += lfo_inc;
    }
    for (int i = 0; i < 6; i++)
    {
      state_.phase_arr[i] = phase_arr[i];
      state_.w_now_arr[i] = w_now_arr[i];
    }
    state_.lfoz = lfoz;
  }

  inline void setParameter(uint8_t index, int32_t value)
  {
    switch (index)
    {
    case WAVE:
      params_.wave = clipminmaxi32(0, value, 1023);
      state_.wave = params_.wave / 1023.f;
      break;

    case DICE:
      if (value == 1 && params_.dice == 0)
      {
        for (int i = 0; i < 6; i++)
        {
          params_.freq_param_arr[i] = osc_rand() % 501 + 100;
          state_.freq_coef_arr[i] = params_.freq_param_arr[i] / 100.f;
        }
      }
      params_.dice = value;
      break;

    case OSC1:
      value = clipminmaxi32(100, value, 600);
      params_.freq_param_arr[0] = value;
      state_.freq_coef_arr[0] = value / 100.f;
      break;

    case OSC2:
      value = clipminmaxi32(100, value, 600);
      params_.freq_param_arr[1] = value;
      state_.freq_coef_arr[1] = value / 100.f;
      break;

    case OSC3:
      value = clipminmaxi32(100, value, 600);
      params_.freq_param_arr[2] = value;
      state_.freq_coef_arr[2] = value / 100.f;
      break;

    case OSC4:
      value = clipminmaxi32(100, value, 600);
      params_.freq_param_arr[3] = value;
      state_.freq_coef_arr[3] = value / 100.f;
      break;

    case OSC5:
      value = clipminmaxi32(100, value, 600);
      params_.freq_param_arr[4] = value;
      state_.freq_coef_arr[4] = value / 100.f;
      break;

    case OSC6:
      value = clipminmaxi32(100, value, 600);
      params_.freq_param_arr[5] = value;
      state_.freq_coef_arr[5] = value / 100.f;
      break;

    case QUANTIZE_DEPTH:
      value = clipminmaxi32(0, value, 100);
      params_.quant_depth = value;
      break;

    case TRANS_TIME:
      value = clipminmaxi32(0, value, 100);
      params_.quant_time = value;
      break;

    default:
      break;
    }
  }

  inline int32_t
  getParameterValue(uint8_t index) const
  {
    switch (index)
    {
    case WAVE:
      return params_.wave;
      break;

    case DICE:
      return params_.dice;
      break;

    case OSC1:
      return params_.freq_param_arr[0];
      break;

    case OSC2:
      return params_.freq_param_arr[1];
      break;

    case OSC3:
      return params_.freq_param_arr[2];
      break;

    case OSC4:
      return params_.freq_param_arr[3];
      break;

    case OSC5:
      return params_.freq_param_arr[4];
      break;

    case OSC6:
      return params_.freq_param_arr[5];
      break;

    case QUANTIZE_DEPTH:
      return params_.quant_depth;
      break;

    case TRANS_TIME:
      return params_.quant_time;
      break;

    default:
      break;
    }

    return INT_MIN; // Note: will be handled as invalid
  }

  inline const char *getParameterStrValue(uint8_t index, int32_t value) const
  {
    // Note: String memory must be accessible even after function returned.
    //       It can be assumed that caller will have copied or used the string
    //       before the next call to getParameterStrValue

    // static const char *param3_strings[NUM_PARAM3_VALUES] = {
    //     "VAL 0",
    //     "VAL 1",
    //     "VAL 2",
    //     "VAL 3",
    // };

    // switch (index)
    // {
    // case PARAM3:
    //   if (value >= PARAM3_VALUE0 && value < NUM_PARAM3_VALUES)
    //     return param3_strings[value];
    //   break;
    // default:
    //   break;
    // }

    return nullptr;
  }

  inline void setTempo(uint32_t tempo)
  {
    // const float bpmf = (tempo >> 16) + (tempo & 0xFFFF) / static_cast<float>(0x10000);
    (void)tempo;
  }

  inline void tempo4ppqnTick(uint32_t counter)
  {
    (void)counter;
  }

  inline void NoteOn(uint8_t note, uint8_t velo)
  {
    (uint8_t) note;
    (uint8_t) velo;

    // Schedule phase reset
    state_.flags |= k_flag_reset;
  }

  inline void NoteOff(uint8_t note)
  {
    (uint8_t) note;
  }

  inline void AllNoteOff()
  {
  }

  inline void PitchBend(uint8_t bend)
  {
    (uint8_t) bend;
  }

  inline void ChannelPressure(uint8_t press)
  {
    (uint8_t) press;
  }

  inline void AfterTouch(uint8_t note, uint8_t press)
  {
    (uint8_t) note;
    (uint8_t) press;
  }

  /*===========================================================================*/
  /* Static Members. */
  /*===========================================================================*/

private:
  /*===========================================================================*/
  /* Private Member Variables. */
  /*===========================================================================*/

  std::atomic_uint_fast32_t flags_;

  unit_runtime_desc_t runtime_desc_;

  Params params_;

  State state_;

  /*===========================================================================*/
  /* Private Methods. */
  /*===========================================================================*/

  /*===========================================================================*/
  /* Constants. */
  /*===========================================================================*/
};
